import pandas as pd
import yaml
from ragas.metrics import LLMContextPrecisionWithoutReference
from langchain_openai import ChatOpenAI
from ragas.llms import LangchainLLMWrapper
from pathlib import Path
import pytest
import os

responseFilePath ="/opt/product/testteam/LoadScript/RagAsTesting/data/"

#user_input -> query
#response -> response
#reference -> groundtruth
#retrieved_context -> top documents from vector database

os.environ["OPENAI_API_KEY"] = "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"


class Dynamic_Response_Validation:

    def __init__(self,testcaseName,ActualResponse):
        self.ActualResponse = ActualResponse
        self.testcaseName = testcaseName
    
    def load_test_data(self):
        directory = Path(__file__).parent.absolute()
        testCaseFile = responseFilePath + "/" + self.testcaseName + ".yaml"
        with open(testCaseFile,"r") as file:
            self.ExpectedResponse = yaml.safe_load(file)
        self.response_validation(self.ExpectedResponse,self.ActualResponse)
 
    def response_validation(self,ExpectedResponse,ActualResponse):
        self.getExpectedData = ''.join(self.ExpectedResponse[self.testcaseName].splitlines())
        self.getActualData = ''.join(self.ActualResponse.splitlines())

        if all(x.lower() in self.getExpectedData.lower() for x in self.getActualData.split(" ")):
            print("All matches found")
        else:
            print("Matches not found")

        print("Expected respone %s" %self.getExpectedData)
        print("Actual respone %s" %self.getActualData)



    @pytest.mark.asyncio
    async def test_context_precision(self):

        #Create Object of class for specific metric
        os.environ["OPENAI_API_KEY"] = "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"

        llm = ChatOpenAI(model="gpt-4o",temperature=0)
        langchain_llm = LangchainLLMWrapper()

        contextPrecision = LLMContextPrecisionWithoutReference(llm=langchain_llm)

        responseDict = requests.post(url="https://rahulshettyacademy.com/rag-llm/ask",
                     json={
                         "question" : "How many articles are there in selenium webdriver",
                         "chat_history":[

                           ]
                     }).json()
        
        #feedData
        sample = SingleTurnSample(
            user_input = "How Many articles are there in selenium webdriver course",
            response = responseDict["answer"],
            retrieved_contexts = [responseDict["retrieved_docs"][0]["page_content"]]
        )

        #score
        score = await contextPrecision.single_turn_score(sample)
        print(score)
        assert(score==1)


    @pytest.mark.asyncio
    @pytest.mark.parametrize(getData,[{"question" : "How many articles are there in selenium webdriver","chat_history":[],"question" : "What is the requirement of this course","chat_history":[]}],indirect=True)
    async def test_context_recall(self,llm_wrapper,getData):

        context_recall = LLMContextRecall(llm=langchain_llm)
        await context_recall.single_turn_ascore(getData)
        print(score)
        assert(score==1)


    @pytest.fixture
    def llm_wrapper(self):
        llm = ChatOpenAI(model="gpt-4o",temperature=0)
        langchain_llm = LangchainLLMWrapper()
        return langchain_llm


    @pytest.fixture
    def getData(self,request):
        testdata = request.param
        sample = SingleTurnSample(user_input = testdata['question'],
                                 retrieved_contexts = [doc["page_content"] for doc in responsedict.get('retrieved_docs')],
                                 reference="23")

        return sample

    @pytest.mark.parametrize("getData",[{"question" : "How many articles are there in selenium webdriver","chat_history":[],"question" : "What is the requirement of this course","chat_history":[]}],indirect=True)
    @pytest.mark.asyncio
    async def test_faithfulness(self,llm_wrapper):
        faithful = Faithfulness(llm=llm_wrapper)
        faithful.single_turn_ascore(sample)
        assert score>0.8

    @pytest.fixture
    def getData():
       testdata = request.param
       responsedict = get_llm_response(testdata)
       sample = SingleTurnSample(user_input = testdata['question'],
                                 response = responseDict['answer'],
                                 retrieved_contexts = [doc["page_content"] for doc in responsedict.get('retrieved_docs')]
                                 )

       return sample


    def get_llm_response(testdata):
       responseDict = requests.post(url="https://rahulshettyacademy.com/rag-llm/ask",
                     json={
                         "question" : testdata['question'],
                         "chat_history":[
                          ]
                     }).json()
       return responseDict 
        

    @pytest.mark.parametrize("getData",[{"question" : "How many articles are there in selenium webdriver","chat_history":[],"question" : "What is the requirement of this course","chat_history":[]}],indirect=True)
    @pytest.mark.asyncio
    async def test_relevance_fatual(self,llm_wrapper, getData):
       metrics = [ResponseRelevancy(llm=llm_wrapper),FactualCorrectness(llm=llm_wrapper)]
       evaldataSet = EvaluationDataSet([getData])
       results = evaluate(dataSet=evaldataSet,metrics=metrics)
       print(results)
       print(results['answer_relevancy'])


    @pytest.fixture
    def getData():
       testdata = request.param
       responsedict = get_llm_response(testdata)
       sample = SingleTurnSample(user_input = testdata['question'],
                                 response = responseDict['answer'],
                                 retrieved_contexts = [doc["page_content"] for doc in responsedict.get('retrieved_docs')],
                                 reference = responseDict['reference']
                           )

       return sample

       
 
    @pytest.mark.parametrize("getData",[{"question" : "How many articles are there in selenium webdriver","chat_history":[],"question" : "What is the requirement of this course","chat_history":[]}],indirect=True)
    @pytest.mark.asyncio
    async def test_topic_topicAdherence(self,llm_wrapper, getData):
        topicScore = TopicAdherence(llm=llm_wrapper)
        score = await topicScore.multi_turn_score(sample)
        assert score>0.8


    @pytest.fixture
    def getData():
        testdata = request.param
        responsedict = get_llm_response(testdata)
        conversation = [
            HumanMessage(content="How many articles are there in selenium webdriver"),
            AIMessage(content="There are 23 articles in the page"),
            HumanMessage(content="How many downloadable are there in course"),
            AIMessage(content="There are 9 downloadable in the page")
        ]
        reference = ["""
        The AI should:
        1. Give results related to Selenium Python course
        2. There are total 23 articles and 9 downloadable files in the path
        """]


        sample = MultiTurnSample(
                     user_input = conversation,
                     reference_topics=reference,
                     response = responseDict['answer'],
                     retrieved_contexts = [doc["page_content"] for doc in responsedict.get('retrieved_docs')],
                     reference = responseDict['reference']
         )

        return sample
