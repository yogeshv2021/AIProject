import jwt
import datetime

SHA256:3hfkxamUz4yb4RHHW3KdWjXdPPIgZgHiJtYS4mbyoog=



SECRET_KEY = "your_secret_key"

PAYLOAD = {

  "sub": "123456",
  "name" : "test",
  "iat": datetime.datetime.utcnow(),
  "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=1)
}

ALGORITHM  = "HS256"


token = jwt.encode(PAYLOAD,SECRET_KEY,ALGORITHM)

print(f"{token}")

