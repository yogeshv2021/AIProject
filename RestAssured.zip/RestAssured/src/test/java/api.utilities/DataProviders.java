package api.utilities;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import api.endpoints.DBRequestExecutor;
import api.endpoints.DBResponseExecutor;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.ss.usermodel.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import api.endpoints.*;


public class DataProviders extends Base {
	
        static String path = Base.configuration() + "TestData.xls";
        static String Dbpath = Base.configuration() + "DBTestData.xls";
        static String SheetName="Sheet1";
        static String TestCaseName;
        static String Method;
        static String Url;
        static String Headers;
        static String Body;
        static File FileObject;
        static FileInputStream f1;
        static Object[][] postdata = null;
        static Object[][] dbdata = null;

	@DataProvider(name="postrequestData")
	public static Object[][] postRequest() throws ArrayIndexOutOfBoundsException,IOException,FileNotFoundException{

            try{
               FileObject = new File(path);
               DataFormatter formatter = new DataFormatter();
               f1 = new FileInputStream(FileObject);
               String method = "";
               HSSFWorkbook b1 = new HSSFWorkbook(f1);
               HSSFSheet s1 = b1.getSheetAt(0);
	       int rowcount = s1.getLastRowNum();
               int cellcount = 0;
               int numberOfRows = 0;
               int countincrement = rowcount;


               for (int i=1;i<=rowcount;i++){
                    HSSFRow row = s1.getRow(i);
                    cellcount = row.getLastCellNum();
                    method = row.getCell(3).getStringCellValue();
                    if (method.equalsIgnoreCase("POST")){
                        numberOfRows++;
                    }
               }

               postdata = new Object[numberOfRows][cellcount];

               for (int i=1;i<=rowcount;i++){
                    HSSFRow row = s1.getRow(i);
                    method = row.getCell(3).getStringCellValue();
                    cellcount = row.getLastCellNum();
                    if (method.equalsIgnoreCase("POST")){
                        for (int j=0;j<cellcount;j++){
                           HSSFCell cell = row.getCell(j);
                           String getcelldata = getCellType(cell);
                           String celldata = getcelldata;
                           postdata[rowcount-countincrement][j] = celldata;
                        }
                    }
                    countincrement = countincrement-1;
               }
               /*DBRequestExecutor.DbMethodCreateQuery(TestCaseName,Method,Url,Headers,Body);*/
             }
             catch(Exception e){
                  e.printStackTrace();
             }
             finally{
                System.out.println("Data provided to base class for execution");
                f1.close();
                return postdata;
            }
      }
	

	@DataProvider(name="getrequestData")
	public static Object[][] getRequest() throws ArrayIndexOutOfBoundsException,IOException,FileNotFoundException{

            Object[][] data = null;

            try{
               FileObject = new File(path);
               DataFormatter formatter = new DataFormatter();
               f1 = new FileInputStream(FileObject);
               String method = null;
               HSSFWorkbook b1 = new HSSFWorkbook(f1);
               HSSFSheet s1 = b1.getSheetAt(0);
	       int rowcount = s1.getLastRowNum();
               int cellcount = 0;
               int countincrement = rowcount;
               int numberOfRows = 0;

               for (int i=1;i<=rowcount;i++){
                    HSSFRow row = s1.getRow(i);
                    cellcount = row.getLastCellNum();
                    method = row.getCell(3).getStringCellValue();
                    if (method.equalsIgnoreCase("GET")){
                        numberOfRows++;
                    }
               }

               data = new Object[numberOfRows][cellcount];

               for (int i=1;i<=rowcount;i++){
                    HSSFRow row = s1.getRow(i);
                    method = row.getCell(3).getStringCellValue();
                    cellcount = row.getLastCellNum();
                    if (method.equalsIgnoreCase("GET")){
                        for (int j=0;j<cellcount;j++){
                           HSSFCell cell = row.getCell(j);
                           String getcelldata = getCellType(cell);
                           String celldata = getcelldata;
                           data[rowcount-countincrement][j] = celldata;
                        }
                    }
                    countincrement = countincrement-1;
               }
               /*DBRequestExecutor.DbMethodCreateQuery(TestCaseName,Method,Url,Headers,Body);*/
             }
             catch(Exception e){
                  e.printStackTrace();
             }
             finally{
                System.out.println("Data provided to base class for execution");
                f1.close();
                return data;
            }
      }


        @DataProvider(name="DBQueryData")
	public static Object[][] DBRequest() throws ArrayIndexOutOfBoundsException,IOException,FileNotFoundException{

            try{
               FileObject = new File(Dbpath);
               DataFormatter formatter = new DataFormatter();
               f1 = new FileInputStream(FileObject);
               String method = null;
               HSSFWorkbook b1 = new HSSFWorkbook(f1);
               HSSFSheet s1 = b1.getSheetAt(0);
	       int rowcount = s1.getLastRowNum();
               int cellcount = 0;
               int countincrement = rowcount;
               int numberOfRows = 0;

               for (int i=1;i<=rowcount;i++){
                    HSSFRow row = s1.getRow(i);
                    cellcount = row.getLastCellNum();
               }

               dbdata = new Object[rowcount][cellcount];

               for (int i=1;i<=rowcount;i++){
                    HSSFRow row = s1.getRow(i);
                    cellcount = row.getLastCellNum();
                    for (int j=0;j<cellcount;j++){
                        HSSFCell cell = row.getCell(j);
                        String getcelldata = getCellType(cell);
                        String celldata = getcelldata;
                        dbdata[rowcount-countincrement][j] = celldata;
                    }
                    countincrement = countincrement-1;
               }
               /*DBRequestExecutor.DbMethodCreateQuery(TestCaseName,Method,Url,Headers,Body);*/
             }
             catch(Exception e){
                  e.printStackTrace();
             }
             finally{
                System.out.println("Data provided to base class for execution");
                f1.close();
                return dbdata;
            }
      }
	

	
        @DataProvider(name="MergeRequestAndDBQueryData")
	public static Object[][] RequestAndDBRequestData() throws ArrayIndexOutOfBoundsException,IOException,FileNotFoundException{

            Object[][] mergeArrayNestedList=null;

            Object[][] postdata = postRequest();
            Object[][] dbdata = DBRequest();

            int getPostDataSize = postdata[0].length;
            int getDBDataSize = dbdata[0].length;
            int mergedataSize = getPostDataSize + getDBDataSize;

            int getObjectLength = postdata.length;
            System.out.println(getObjectLength);

            List<Object[]> getPostList = new ArrayList<>();
            List<Object[]> getDBList = new ArrayList<>();
            List<Object[]> newList = new ArrayList<>();
            List<Object> createList = new ArrayList<>();

            int count=0;
            int row =0;

            try{

                for (Object[] getPostData: postdata){
                    getPostList.add(getPostData);
                }

                for (Object[] getDBArray: dbdata){
                    getDBList.add(getDBArray);
                }


                List<Object> getFirstItem1=new ArrayList<>(Arrays.asList(getPostList.get(0)));
                List<Object> getDBItem1=new ArrayList<>(Arrays.asList(getDBList.get(0)));
                getFirstItem1.addAll(getDBItem1);

                mergeArrayNestedList= new Object[getObjectLength][getFirstItem1.size()];

                for (int i=0;i<getObjectLength;i++){
                   List<Object> getFirstItem=new ArrayList<>(Arrays.asList(getPostList.get(i)));
                   List<Object> getDBItem=new ArrayList<>(Arrays.asList(getDBList.get(i)));
                   getFirstItem.addAll(getDBItem);
                   System.out.println(getFirstItem);
                   for (int j=0;j<getFirstItem1.size();j++){
                      mergeArrayNestedList[i][j] = getFirstItem.get(j);
                   }
                }

                System.out.println("list:" + mergeArrayNestedList[0] + mergeArrayNestedList[1]);
                return mergeArrayNestedList;

             }
             catch(Exception e){
                  e.printStackTrace();
                  return mergeArrayNestedList;
             }
             finally{
                f1.close();
                return mergeArrayNestedList;
              }
  
      }
	


	  static String getCellType(Cell cell) {
		  
		  String result="";
		  
		  CellType type = cell.getCellType();
		  
		  switch (type) {
		      case STRING:
		    	 result=cell.getStringCellValue();
		      break;
		      case NUMERIC:
		    	  result=String.valueOf(cell.getNumericCellValue());
			      break;
		      case BOOLEAN:
		    	  result=String.valueOf(cell.getBooleanCellValue());
			      break;
		      case ERROR:
		    	  result=String.valueOf(cell.getErrorCellValue());
			      break;
		      case BLANK:
		    	  result="";
			      break;
			  default:
			      result="";
		  }
		  return result;
	  }
}

