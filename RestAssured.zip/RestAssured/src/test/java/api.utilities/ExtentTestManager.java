package api.utilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import api.endpoints.DbRedisExecutor;


public class ExtentTestManager extends DbRedisExecutor{

    private static ThreadLocal<ExtentTest> extentTest = new ThreadLocal<>();
    public static ExtentTest test;
    private static ExtentReports extent = ExtentManager.getInstance();

     public static synchronized ExtentTest getTest(){
        return extentTest.get();
     }

     public static synchronized void endTest(){
        extent.flush();
     }

     public static synchronized ExtentTest startUp(String TestCase,String Description){
        test = extent.createTest(TestCase,Description);
        extentTest.set(test);
        return test;
     }

}

class ExtentManager{

     private static ExtentReports extent;

     public synchronized static ExtentReports getInstance(){

        ExtentSparkReporter htmlReporter = new ExtentSparkReporter("test-output/reporter.html");


        if (extent==null){

           htmlReporter.config().setTheme(Theme.DARK);
           htmlReporter.config().setDocumentTitle("CEP-API Test Report");
           htmlReporter.config().setReportName("Rest Assured Test Result");
        }

        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
        extent.setSystemInfo("CEP Automation","Testing");
        extent.setSystemInfo("Environment","QA");

        return extent;

     } 

}
