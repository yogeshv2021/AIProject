package api.endpoints;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;

import org.json.JSONArray;
import org.json.JSONObject;
import com.opencsv.*;
import org.json.JSONTokener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;
import static io.restassured.RestAssured.*;
import io.restassured.http.Method;
import io.restassured.specification.RequestSpecification;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;

import io.restassured.response.*;
import io.restassured.matcher.RestAssuredMatchers.*;
import io.restassured.path.json.JsonPath;

import static org.hamcrest.Matchers.*;
import io.restassured.response.ExtractableResponse;
import io.restassured.response.ValidatableResponse;

import org.testng.asserts.SoftAssert;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.junit.jupiter.api.*;
import org.testng.annotations.Test;
import java.util.Properties;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class APIRequest extends Base{

   private static Properties properties;
   private ExtentReports extent;
   private ExtentTest test;

   public static LinkedHashMap<String,Object> stringtoMap(String header,String Separator){

        LinkedHashMap<String,Object> HeaderContent = new LinkedHashMap<String,Object>();
        String getContent=null;

        if (header.substring(0,1).equals("{")){
            getContent = header.substring(1,header.length()-1);
        }
        else{
            getContent = header.substring(0,header.length());
        }
        
        String[] getelement = getContent.split(",");
        for (int i=0;i<getelement.length;i++){
                String element = getelement[i];
                String key = element.split(Separator)[0].trim();
                String value = element.split(Separator)[1].trim();
                HeaderContent.put(key,value);
        } 
        return HeaderContent;
    }

    public static Response sendGetMethod(String uri,String path,Map<String,Object> header){

        Response response =null;
        try{
            RequestSpecBuilder specbuilder = new RequestSpecBuilder().setUrlEncodingEnabled(false);
            RequestSpecification requestspec = specbuilder.build();
            response = given()
            .spec(requestspec)
            .baseUri(properties.getProperty("Nginx_uri"))
            .basePath(path)
            .contentType(ContentType.JSON)
            .headers(header)
            .when().get();
            return response;
        }     
        catch(Exception e){
           e.printStackTrace();
           return response;
        }
    }

    public static Response sendPostMethod(String uri,String path,Map<String,Object> header,String body){
        Response response =null;
        try{
            RequestSpecBuilder specbuilder = new RequestSpecBuilder().setUrlEncodingEnabled(false);
            RequestSpecification requestspec = specbuilder.build();
            response = given()
            .spec(requestspec)
            .baseUri(uri)
            .basePath(path)
            .contentType(ContentType.JSON)
            .headers(header)
            .body(body)
            .when().post();
            return response;
        }     
        catch(Exception e){
           e.printStackTrace();
           return response;
        }


    }

    public LinkedHashMap<String,String> responsebody(){

           LinkedHashMap<String,String> bodymap = new LinkedHashMap<String,String>();
           bodymap.put("code","50136");
           bodymap.put("message","Already Flow Execution for the combination of given Virtual Number and User Number");
           return bodymap;
    }

    public static Object checkDBMap(LinkedHashMap<String,Object> getBody,String DB_Condition){
        Object Value=null;
        if (getBody instanceof Map){
           for (Map.Entry<String,Object> m1: getBody.entrySet() ){
                String key = m1.getKey();
                Value = m1.getValue();

                if (Value instanceof Map){
                      LinkedHashMap<String,Object> getValue = (LinkedHashMap<String,Object>) Value;
                      checkDBMap(getValue,DB_Condition);
                 }
                 else if (Value instanceof List){
                      List<Object> getValue = (List<Object>) Value;
                      checkDBList(key,getValue,DB_Condition);
                 }
                  else if (key.equals(DB_Condition)){
                      return Value;
                 }
                 else{
                     return Value;
                 }
            }
       }
       return Value;

    }

    public static Object checkDBList(String key,List<Object> Value,String DB_Condition){
        Object StrValue =null;
        for (Object newValue: Value ){
           StrValue = newValue;
           if (key.equals(DB_Condition)){
                return StrValue;
            }
            else if (StrValue instanceof List){
                List<Object> getValue = (List<Object>) StrValue;
                checkDBList(key,getValue,DB_Condition);
            }
            else{
               return StrValue;
            }
        }
        return StrValue;

    }


}
