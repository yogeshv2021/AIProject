package api.endpoints;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import java.util.Map;
import java.util.List;

public class DbRedisExecutor{

    private static JedisPool pool;

    public DbRedisExecutor(){
      try{
         JedisPoolConfig jedispool = new JedisPoolConfig();
         pool= new JedisPool(jedispool,"172.18.1.51",9063);
      }
      catch(Exception e){
          e.printStackTrace();
      }
   }

   public static String getValue(String key){
      System.out.println(key);
      Jedis jedis= pool.getResource();
      return jedis.get(key);
   }

   public static void SetValue(String key,String value){
      Jedis jedis= pool.getResource();
      jedis.set(key,value);
   }

   public static Map<String,String> getHashValue(String key){
      Jedis jedis= pool.getResource();
      System.out.println("Key to Query for PostCondition" + ":" + key);
      return jedis.hgetAll(key);
   }

   public static void setHashValue(String key,Map<String,String> value){
      Jedis jedis= pool.getResource();
      jedis.hset(key,value);
   }

   public static List<String> getListValue(String key){
      Jedis jedis= pool.getResource();
      return jedis.lrange(key,0,-1);
   }

   public static void setListValue(String key,String Value){
      Jedis jedis= pool.getResource();
      jedis.lpush(key,Value);
   }

   public void close(){
     pool.close();
   }


}
