package api.endpoints;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLTimeoutException;
import java.util.*;
import utils.*;

public class DBRequestExecutor{


    private static final String url = "jdbc:postgresql://172.18.1.41:5432/cpaas_lyca_ireland_test?currentSchema=st_load_test_1";
    private static final String user = "postgres";
    private static final String password = "postgres";
    public static String fname = null;

    public static Connection conn;
    public static PreparedStatement prst;
    public static ResultSet getqueryoutput;
    public static int getoutput;
    public static String Query ="select *From apiResponseValidator";

    public static String requestmethod =null;
    public static String requesturl =null;
    public static Integer requeststatuscode =0;
    public static String requestheader =null;
    public static String requestbody =null;
    public static String requesttestcase =null;
    public static Integer updateresult =0;

    public static String insertquery="Insert Into apiResponseValidator (TestCaseName,Method,Url,ResponseStatusCode,ResponseHeader,ResponseBody) values(?,?,?,?,?,?)";
    public static String selectquery="select * from apiResponseValidator where TestCaseName=?";
    public static String updatequery="Update apiResponseValidator set Method=?,Url=?,ResponseStatusCode=?,ResponseHeader=?,ResponseBody=? where TestCaseName=?";

    public static void createTable(Connection conn){

       try{

            String CreateTableSql = "CREATE TABLE IF NOT EXISTS apiResponseValidator ("+
                "Id SERIAL PRIMARY KEY,"+
                "TestCaseName VARCHAR(100) UNIQUE NOT NULL,"+
                "Method VARCHAR(100) NULL,"+
                "Url VARCHAR(100) NULL,"+
                "ResponseStatusCode VARCHAR(100) NULL,"+
                "ResponseHeader VARCHAR(10000) NULL,"+
                "ResponseBody VARCHAR(10000) NULL,"+
                "CreatedTime TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"+
                "UpdatedTime TIMESTAMP DEFAULT CURRENT_TIMESTAMP"+
                ");";

            Statement stmt= conn.createStatement();
            int result = stmt.executeUpdate(CreateTableSql);
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }


    public static void DbMethodCreateQuery(String TestCaseName,String Method,String Url,Integer StatusCode,String Headers,String Body){

       try{
          Class.forName("org.postgresql.Driver");
          conn = DriverManager.getConnection(url,user,password);
          createTable(conn);

          prst = conn.prepareStatement(Query);
          System.out.println("Connection to database is successfull");

          LinkedList<Object> getDBRows = new LinkedList<>(Arrays.asList(TestCaseName,Method,Url,StatusCode,Headers,Body,conn));
          DbMethodUpdateQuery(getDBRows);
   
      }
      catch(SQLException| ClassNotFoundException e){
              System.out.println("Exception occured" + e);
      }
      finally{
        try{
          if (conn !=null) {
            conn.close();
          }
          if (prst!=null) {
             prst.close();
          }
        }
        catch (SQLException e){
              System.out.println("Exception occured" + e);
        }
      }
    }



    public void DbMethodDeleteQuery(String Query){
       try{
          Class.forName("org.postgresql.Driver");
          conn = DriverManager.getConnection(url,user,password);
          prst = conn.prepareStatement(Query);
          System.out.println("Connection to database is successfull");
          getqueryoutput = prst.executeQuery();
   
          while (getqueryoutput.next()){
            System.out.println(getqueryoutput);
         }
      }
      catch(SQLException| ClassNotFoundException e){
              System.out.println("Exception occured" + e);
      }
      finally{
        try{
          if (conn !=null) {conn.close();};
          if (prst!=null) {prst.close();}; 
        }
        catch (SQLException e){
              System.out.println("Exception occured" + e);
        }
      }
    }

    public static void DbMethodUpdateQuery(LinkedList<Object> getDBRows){

       try{

          conn = (Connection) getDBRows.get(6);
          requesttestcase = (String) getDBRows.get(0);
          requestmethod = (String)  getDBRows.get(1);
          requesturl = (String) getDBRows.get(2);
          requeststatuscode = (Integer) getDBRows.get(3);
          requestheader = (String) getDBRows.get(4);
          requestbody = (String) getDBRows.get(5);

          try{
             System.out.println("Testcase to be executed " + requesttestcase);
             boolean getSelectQueryValue = DbMethodSelectQuery(selectquery,requesttestcase,conn);
             System.out.println(getSelectQueryValue);

             if (getSelectQueryValue == true){
                 prst = conn.prepareStatement(updatequery);
                 prst.setString(1,requestmethod);
                 prst.setString(2,requesturl);
                 prst.setInt(3,requeststatuscode);
                 prst.setString(4,requestheader); 
                 prst.setString(5,requestbody); 
                 prst.setString(6,requesttestcase);

                 updateresult = prst.executeUpdate();

                 if (updateresult ==0){
                   System.out.println("Issue in record updation (or) testcase is not present in DB.");
                 }
                 else{
                   System.out.println("Record updated successfully");

                 }
             }
             else{
                 prst = conn.prepareStatement(insertquery);
                 System.out.println(prst);
                 prst.setString(1,requesttestcase);
                 prst.setString(2,requestmethod);
                 prst.setString(3,requesturl);
                 prst.setInt(4,requeststatuscode);
                 prst.setString(5,requestheader); 
                 prst.setString(6,requestbody); 

                 System.out.println("Insert row into database");

                 getoutput = prst.executeUpdate();                 

             }
          }
          catch(SQLException e){
                 System.out.println(e.getMessage());
                 prst = conn.prepareStatement(insertquery);
                 System.out.println(prst);
                 prst.setString(1,requesttestcase);
                 prst.setString(2,requestmethod);
                 prst.setString(3,requesturl);
                 prst.setInt(4,requeststatuscode);
                 prst.setString(5,requestheader); 
                 prst.setString(6,requestbody); 

                 System.out.println("Insert row into database");

                 getoutput = prst.executeUpdate();                 
                  
                 System.out.println(getoutput);
          }
      }
      catch(SQLException e){
              System.out.println("Exception occured while updating the table" + e);
      }
      finally{
        try{
          if (conn !=null) {conn.close();};
          if (prst!=null) {prst.close();}; 
        }
        catch (SQLException e){
              System.out.println("Exception occured" + e);
        }
      }
    }


    public static LinkedHashMap<String,List<Object>> DbMethodFetchQuery(String TestName) throws SQLException{

       LinkedHashMap<String,List<Object>> getmap = new LinkedHashMap<String,List<Object>>();

       try{
          Class.forName("org.postgresql.Driver");
          conn = DriverManager.getConnection(url,user,password);
          getmap = DbMethodFetchTCResult(TestName,conn);
          return getmap;
       }
       catch(SQLException| ClassNotFoundException e){
          if (conn !=null) {conn.close();}
          if (prst!=null) {prst.close();}
          System.out.println("Exception occured while fetching the result for testcase: " + e.getMessage());
          return getmap;
       }
       finally{
        try{
          if (conn !=null) {conn.close();}
          if (prst!=null) {prst.close();}
        }
        catch (SQLException e){
           System.out.println("Exception occured while closing the connection for testcase result" + e.getMessage());
        }
       }
    }

    public static boolean DbMethodSelectQuery(String selectquery,String requesttestcase,Connection conn){
       try{
             prst = conn.prepareStatement(selectquery);
             prst.setString(1,requesttestcase);
             getqueryoutput = prst.executeQuery();

             if (getqueryoutput.next()){
                return true;
             }
             else{
                return false;
             }
      }
      catch(SQLException e){
           System.out.println("Exception occured" + e.getMessage());
           return false;
      }
    }

    public static LinkedHashMap<String,List<Object>> DbMethodFetchTCResult(String TestName,Connection conn){

       LinkedHashMap<String,List<Object>> Resultmap= new LinkedHashMap<String,List<Object>>();

       try{
          prst = conn.prepareStatement(selectquery);
          prst.setString(1,TestName);
          ResultSet recordSet =prst.executeQuery();
 
          while (recordSet.next()){
            requesttestcase =  recordSet.getString("TestCaseName");
            requestheader =  recordSet.getString("ResponseHeader");
            requestbody =  recordSet.getString("ResponseBody");
            Resultmap.put(requesttestcase,Arrays.asList(requestheader,requestbody));
          }

          System.out.println("result " + Resultmap);
          return Resultmap;
       }
      catch(SQLException e){
         System.out.println("Exception occured while fetching result for testcase: " + e.getMessage());
         return Resultmap;
      }
   }
}
