package api.endpoints;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;

import org.json.JSONArray;
import org.json.JSONObject;

import com.opencsv.*;
import org.json.JSONTokener;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import com.fasterxml.jackson.core.type.TypeReference;
import java.lang.reflect.Array;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;
import static io.restassured.RestAssured.*;
import io.restassured.http.*;
import io.restassured.path.json.JsonPath;
import io.restassured.specification.RequestSpecification;
import io.restassured.builder.RequestSpecBuilder;

import io.restassured.response.*;
import io.restassured.matcher.RestAssuredMatchers.*;
import io.restassured.path.json.JsonPath;
import org.testng.ITestResult;


import static org.hamcrest.Matchers.*;
import io.restassured.response.ExtractableResponse;
import io.restassured.response.ValidatableResponse;

import org.testng.asserts.SoftAssert;
import org.testng.annotations.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

import java.util.Properties;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.Status;
import api.utilities.DataProviders;
import api.utilities.ExtentTestManager;
import com.aventstack.extentreports.ExtentTest;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.*;
import org.junit.jupiter.api.BeforeAll;
import java.lang.reflect.Method;
import utils.ConfigReader;
import api.endpoints.*;
import com.fasterxml.jackson.core.JsonParseException;

public class Base extends ExtentTestManager{

        ExtentReports extent;
        public static String providerPath;
        public static LinkedHashMap<String,Object> bodyDynamicResponseContent = new LinkedHashMap<String,Object>();
        public static Integer bodyDynamicflag=2;
        public static Boolean getTypeResult =true;
        public static ObjectMapper mapper = new ObjectMapper();
        public static HashMap<String,Object> getMapValue =new HashMap<String,Object>();
        public static String getHeaders =null;
        public static String getBody =null;
        public static Object getOutput =null;

        public static LinkedHashMap<String,Object> getHeadersMap =null;
        public static LinkedHashMap<String,Object> getBodyMap =null;
        public static ThreadLocal<SoftAssert> softAssert= new ThreadLocal<>();
        public static String actualValue =null;
        public static String expectedValue =null;
        public static Object getBodyType = null;

        @BeforeSuite
        public static String configuration(){
            providerPath = ConfigReader.getInstance().getDataProviderPath("dataProviderPath");
            return providerPath;
        }


          @BeforeMethod
          public static void setUp(Method method){
              ExtentTest test = ExtentTestManager.startUp(method.getName(),  "Description is " + method.getName()); 
              System.out.println(test);
              softAssert.set(new SoftAssert());
          }
 
          public static Map<String,LinkedHashMap<String,Object>> requestPostContent(String Request_Method,String Request_Header,String Request_Body_Type,String Request_Body,Object getPassValue){

               String requestBodyJson ="";	

               Map<String,LinkedHashMap<String,Object>> requestHeaderBody = new LinkedHashMap<String,LinkedHashMap<String,Object>>();

               try{

                      LinkedHashMap<String,Object> headerContent = new LinkedHashMap<String,Object>();
                      LinkedHashMap<String,Object> BodyContent = new LinkedHashMap<String,Object>();
                      LinkedHashMap<String,Object> DependentCheckFlag = new LinkedHashMap<String,Object>();

                      String jsonbody = "";

                      Integer getDependentValue =2;

                      String[] headerdata = Request_Header.split(";");

                      Integer Response = 2;


                      for (String header: headerdata){
                          String[] keyvalue = header.split(":");
                          headerContent.put(keyvalue[0],keyvalue[1]);
                      }

                      String getExpectedResponseObject =null;

                      getDependentValue = checkType(getPassValue);

                      if (getPassValue!=null && getDependentValue ==1){
                         Response = 0;
                         String getPassStr = mapper.writeValueAsString(getPassValue);
                         Map<String,Object> getpassvalueMap = mapper.readValue(getPassStr,Map.class);
                         String getkeyValue = getpassvalueMap.entrySet().iterator().next().getKey();
                         String getValue = getpassvalueMap.entrySet().iterator().next().getValue().toString();

                         JsonNode getNode = mapper.readTree(Request_Body); 
                         ObjectNode object = (ObjectNode) getNode;
                         String getstrKey = getkeyValue.replace("\"","");
                         String getstrValue = getValue.replace("\"","");
                         object.put(getstrKey,getstrValue);                        
                         getExpectedResponseObject = mapper.writeValueAsString(object); 

                     }
                     else if  (getPassValue!=null && getDependentValue ==0){
                         Response = 1;
                         JsonNode getNode = mapper.readTree(Request_Body); 
                         ObjectNode object = (ObjectNode) getNode;
                         getExpectedResponseObject = mapper.writeValueAsString(object); 
                     }

                     else if  (getPassValue==null && getDependentValue ==0){
                         Response = 2;
                         JsonNode getNode = mapper.readTree(Request_Body); 
                         ObjectNode object = (ObjectNode) getNode;
                         getExpectedResponseObject = mapper.writeValueAsString(object); 
                     }

                     DependentCheckFlag.put("dependentFlag",Response);

                     requestHeaderBody.put("Flag",DependentCheckFlag);

                     requestHeaderBody.put("requestHeader",headerContent);

                     BodyContent.put("requestBody",getExpectedResponseObject);

                     requestHeaderBody.put("Body",BodyContent);


           }
           catch(Exception e){
                 e.printStackTrace();
           } 

            return requestHeaderBody;

        }



           public static void responsePostContent(String Response_Header,String Response_Body,String Status_Code,Response response,String Dynamic_Response_Header_Content,String Dynamic_Response_Body_Content){

               String Actualjsonresponse=null;
               LinkedHashMap<String,Object> ActualBodymap=null;
               LinkedHashMap<String,Object> bodyResponseExpectedContent=null;
               LinkedList<Object> l2 =null;
               LinkedList<Object> l3 =null;
               String[] dynamic_header = {};
               String[] dynamic_body = {};
               Integer headerDynamicflag =0;

               try{
                      LinkedHashMap<String,Object> headerResponseContent = new LinkedHashMap<String,Object>();
                      LinkedHashMap<String,Object> headerDynamicResponseContent = new LinkedHashMap<String,Object>();

                      String jsonbody = "";

                      String[] headerresponsedata = Response_Header.split(";");
                      for (String header: headerresponsedata ){
                          String[] keyvalue = header.split(":");
                          headerResponseContent.put(keyvalue[0],keyvalue[1]);
                      }

                System.out.println("Received header response:" + " " + headerResponseContent);

                Integer actualStatusCode = response.getStatusCode();
                String statusline = response.getStatusLine();
                Headers Actualresponseheader = response.headers();
                if (actualStatusCode !=405){
                   ResponseBody Actualresponsebody = response.getBody();
                   Actualjsonresponse = Actualresponsebody.asString();
                   System.out.println("Received Responsebody:" + " " + Actualjsonresponse);
                }

                System.out.println("Response Status code: " + actualStatusCode);

                Integer expectedStatusCode = (int) Float.parseFloat(Status_Code);
                softAssert.get().assertEquals(actualStatusCode,expectedStatusCode);
 
                if (Dynamic_Response_Header_Content.equalsIgnoreCase("NA")){
                   System.out.println("Dynamic response header not present for test");
                }
                else{
                   dynamic_header = Dynamic_Response_Header_Content.split(";");
                   for (String dynamic_header_iter: dynamic_header){
                          String[] dynamic_header_list = dynamic_header_iter.split(":");
                          headerDynamicResponseContent.put(dynamic_header_list[0],dynamic_header_list[1]);
                   }
                }
 
                if (Dynamic_Response_Body_Content.equalsIgnoreCase("NA")){
                   System.out.println("Dynamic response body not present for test");
                }
                else{
                   dynamic_body = Dynamic_Response_Body_Content.split(";");
                   for (String dynamic_body_iter: dynamic_body){
                          String[] dynamic_body_list = dynamic_body_iter.split(":");
                          bodyDynamicResponseContent.put(dynamic_body_list[0],dynamic_body_list[1]);
                   }
                }
 
                for (Map.Entry<String,Object> m1: headerResponseContent.entrySet()){

                     String expectedkey = m1.getKey().trim();
                     expectedValue = m1.getValue().toString().trim();

                     if (headerDynamicResponseContent.containsKey(expectedkey)){
                          expectedValue  = (String) headerDynamicResponseContent.get(expectedkey);
                          headerDynamicflag = 1;
                     }
                     else{
                          headerDynamicflag = 0;
                     }
                      for (Header header: Actualresponseheader){
                          String ActualKey = header.getName().trim();
                       
                         if (expectedkey.equalsIgnoreCase(ActualKey)){
                             String ActualValue = response.header(ActualKey).trim();
                             if (headerDynamicflag == 0){
                                softAssert.get().assertEquals(ActualValue,expectedValue,"No Match Found");
                             }
                             else if (headerDynamicflag == 1){
                                try{
                                  System.out.println(ActualValue + "," + expectedValue);
                                  assertThat("No Match Found",ActualValue,matchesPattern(expectedValue));
                                }
                                catch(AssertionError e){
                                  softAssert.get().fail("No Match Found");
                                }
                             }

                             String ExpectedheaderResult= "Expected Header name: " + expectedkey + ", Expected Header value: " + expectedValue;
                             String ActualheaderResult= "Actual Header name: " + ActualKey  + ", Actual Header value: " + ActualValue;
                             ExtentTestManager.test.log(Status.INFO,ExpectedheaderResult);
                             ExtentTestManager.test.log(Status.INFO,ActualheaderResult);
                         }
                     }
                }

                ObjectMapper mapper = new ObjectMapper();
                if (actualStatusCode !=405){
                      ActualBodymap = mapper.readValue(Actualjsonresponse,new TypeReference<LinkedHashMap<String,Object>>(){});
                }
 
                     bodyResponseExpectedContent = mapper.readValue(Response_Body,LinkedHashMap.class);

                     if (actualStatusCode !=405){

                        Object obj = ActualBodymap.getClass().getName();

                        if (obj.equals("java.util.LinkedHashMap")){

                          for (Map.Entry<String,Object> m3: ActualBodymap.entrySet()){
                              Object getActualType =  m3.getValue().getClass().getName(); 

                              Integer getbodysize= bodyResponseExpectedContent.size();
                              String getkey = bodyResponseExpectedContent.keySet().iterator().next();
                              Object getvalue = bodyResponseExpectedContent.get(m3.getKey());
 
                              if (getvalue != null){
			           getBodyType = getvalue.getClass().getName(); 
                              }

                              getTypeResult = wrapperClass(getActualType);

                              if ( getBodyType == null ){
                                 AssertionMethods(m3.getKey(),m3.getValue(),m3.getKey(),getvalue);
                              }

                              else if ( getTypeResult && getbodysize==1 && !( getBodyType.equals("java.util.LinkedHashMap") || getBodyType.equals("java.util.ArrayList") ) ){

                                 bodyDynamicflag = AssertionMethods(m3.getKey(),m3.getValue(),m3.getKey(),getvalue);
                                 System.out.println(bodyDynamicflag);
                              }
                              else if ( getTypeResult && !( getBodyType.equals("java.util.LinkedHashMap") || getBodyType.equals("java.util.ArrayList") ) ){

                                 bodyDynamicflag = AssertionMethods(m3.getKey(),m3.getValue(),m3.getKey(),getvalue);
                                 System.out.println(bodyDynamicflag);
                              }

                              else if (getActualType.equals("java.util.LinkedHashMap")){

                                 LinkedHashMap<String,Object> l1 = (LinkedHashMap<String,Object>)m3.getValue();
                                 System.out.println("Nested Map is found");
                                 for (Map.Entry<String,Object> m4: l1.entrySet()){
                                    Object getTypes =  m4.getValue().getClass().getName();
                                    getTypeResult = wrapperClass(getTypes);
    			            getBodyType = bodyResponseExpectedContent.entrySet().iterator().next(); 
                                    if (getTypeResult && !(getBodyType.equals("java.util.LinkedHashMap") || getBodyType.equals("java.util.ArrayList"))){
                                       bodyDynamicflag = AssertionMethods(m4.getKey(),m4.getValue(),bodyResponseExpectedContent.entrySet().iterator().next().getKey(),bodyResponseExpectedContent.entrySet().iterator().next().getValue());
                                       if (bodyDynamicflag<2){
                                          System.out.println(bodyDynamicflag);
                                          break;
                                       }
                                    }
                                    else if (getActualType.equals("java.util.LinkedHashMap")){
                                       LinkedHashMap<String,Object> m6 = (LinkedHashMap<String,Object>) m3.getValue();
                                       MapAssertionMethod(m6,bodyResponseExpectedContent);
                                    }
                                    else if(getActualType.equals("java.util.ArrayList")){
                                       String Listactualkey = m4.getKey().trim();
                                       List<Object> ListactualValue = (List<Object>) m4.getValue();
                                       System.out.println("Entered into List Method Comparison" + " " + ListactualValue);
                                       ListAssertionMethod(Listactualkey,ListactualValue,bodyResponseExpectedContent);
                                    }
                                }
                            }
                         }
                      }
                   }
                System.out.println("Before Assertion done");
                System.out.println("Assertion done");
           }
           catch(Exception e){
               e.printStackTrace();
           }
        }

        public static String checkJsonType(Object expectedValue) throws Exception,JsonParseException{

              String getstrObject = mapper.writeValueAsString(expectedValue);
              Object getObject = mapper.readValue(getstrObject,Object.class);
              System.out.println(getObject);

              if (getObject instanceof Map){
                 return "Map";
              }
              else if (getObject instanceof List){
                 return "List";
              }
              else{
                 return "String";
              }
        }


        public static Integer checkType(Object getObjectValue){

              if (getObjectValue ==null){
                 return 0;
              }
              else if (getObjectValue instanceof Map){
                 return ((Map)getObjectValue).size();
              }
              else if (getObjectValue instanceof Set){
                 return ((Set)getObjectValue).size();
              }
              else if (getObjectValue instanceof List){
                 return ((List)getObjectValue).size();
              }
              else if (getObjectValue instanceof String){
                 return ((String)getObjectValue).length();
              }
              else if (getObjectValue instanceof Integer){
                 Integer getValue = String.valueOf(getObjectValue).length();
                 return getValue;
              }
              else if (getObjectValue.getClass().isArray()){
                 return Array.getLength(getObjectValue);
              }

              else{
                return 0;
              }

        }



        public static boolean wrapperClass(Object getType){
               if (getType.equals("java.lang.String") || getType.equals("java.lang.Number") || getType.equals("java.lang.Boolean") || getType.equals("java.lang.Character")||getType.equals("java.lang.Boolean")||getType.equals("java.lang.Integer")||getType.equals("java.lang.Double")){
                  return true;
               }
               else{
                  return false;
               }
        }

        public static Integer AssertionMethods(String actualkey,Object actualValue,String expectedkey,Object expectedValue){

                System.out.println("Assert function" + ":" + actualkey + " " + actualValue + " " + expectedValue);

                if (expectedkey.equalsIgnoreCase(actualkey) && bodyDynamicResponseContent.containsKey(expectedkey)){
                   expectedValue  = (String) bodyDynamicResponseContent.get(actualkey);
                   bodyDynamicflag = 1;
                }
                else if (expectedkey.equalsIgnoreCase(actualkey)){
                   bodyDynamicflag = 0;
                }
                else{
                   bodyDynamicflag = 2;
                }
             

             if ( (actualValue instanceof Object) &&  (expectedValue instanceof Object) ){
                Integer getActualValue = checkType(actualValue);
                Integer getExpectedValue = checkType(expectedValue);
                if (getActualValue==0 && getExpectedValue==0){
                    return 0;
                }
             }

             String ActualValue= String.valueOf(actualValue);
             String Expectedvalue= String.valueOf(expectedValue);

             if (expectedkey.equalsIgnoreCase(actualkey) && expectedValue!=null){
                if (bodyDynamicflag == 0){
                   softAssert.get().assertEquals(ActualValue,Expectedvalue,"No Match Found");
                }
                else if (bodyDynamicflag == 1){
                  try{
                    System.out.println(ActualValue + "," + expectedValue);
                    assertThat("No Match Found",ActualValue,matchesPattern(Expectedvalue));
                  }
                  catch(AssertionError e){
                   softAssert.get().fail("No Match Found");
                  }	
                }
              }

              String ExpectedBodyResult= "Expected Header name: " + actualkey + ", Expected Header value: " + Expectedvalue;
              String ActualBodyResult= "Actual Header name: " + actualkey + ", Actual Header value: " + ActualValue;
              ExtentTestManager.test.log(Status.INFO,ExpectedBodyResult);
              ExtentTestManager.test.log(Status.INFO,ActualBodyResult);

              return bodyDynamicflag;
        }


        public static void ListAssertionMethod(String Listactualkey,List<Object> ListactualValue,LinkedHashMap<String,Object> bodyResponseExpectedContent) throws Exception{

             for (Object getValue: ListactualValue){
                System.out.println(getValue.getClass().getName());
                if (getValue.getClass().getName().equals("java.util.LinkedHashMap")){
                    LinkedHashMap<String,Object> getMapValue = (LinkedHashMap<String,Object>) getValue;
                    MapAssertionMethod(getMapValue,bodyResponseExpectedContent);
                    Object expectedValue = bodyResponseExpectedContent.get(Listactualkey);
                    actualValue = getMapValue.toString();
                    if (expectedValue ==null){
                       break;
                    }
                    String getType = checkJsonType(actualValue);
                    System.out.println(getType + ":" + actualValue);
                    System.out.println(expectedValue + ":" +actualValue );
                    softAssert.get().assertEquals(actualValue,expectedValue,"No Match Found for response Body.");
                    String ExpectedBodyResult= "Expected Header name: " + Listactualkey  + ", Expected Header value: " + bodyResponseExpectedContent.get(Listactualkey);
                    String ActualBodyResult= "Actual Header name: " + Listactualkey + ", Actual Header value: " + actualValue;
                    ExtentTestManager.test.log(Status.INFO,ExpectedBodyResult);
                    ExtentTestManager.test.log(Status.INFO,ActualBodyResult);
                }
                else {
                    for (Object getiterValue: ListactualValue){
                       if (getiterValue.getClass().getName().equals("java.util.ArrayList")){
                           ArrayList<Object> getListValue = (ArrayList<Object>) getiterValue;
                           ListAssertionMethod(Listactualkey,getListValue,bodyResponseExpectedContent);
                        }
                       else{
                           AssertionMethods(Listactualkey,getiterValue,Listactualkey,bodyResponseExpectedContent.get(Listactualkey));
                    }
                }
             }
         }
     }

       

        public static void MapAssertionMethod(LinkedHashMap<String,Object> m4,LinkedHashMap<String,Object> expectedMapValue) throws Exception{

             System.out.println("Entered into map assertion Method" + " : " + m4);

             for (Map.Entry<String,Object> m5: m4.entrySet()){
                  String actualkey = m5.getKey().trim();
                  Object getObjectValue = m5.getValue();
                  if (getObjectValue.getClass().getName().equals("java.util.LinkedHashMap")){
                     LinkedHashMap<String,Object> getMapValue = (LinkedHashMap<String,Object>) getObjectValue;
                     MapAssertionMethod(getMapValue,expectedMapValue);
                  }
                  else if (getObjectValue.getClass().getName().equals("java.util.ArrayList")){
                      ArrayList<Object> getListValue = (ArrayList<Object>) getObjectValue;
                      ListAssertionMethod(actualkey,getListValue,expectedMapValue);
                  }
                  else{
                     String getType = checkJsonType(expectedMapValue);
                     System.out.println(getType + ":" + expectedMapValue);

                     if (getType.equalsIgnoreCase("Map")){

                         String getstrObject = mapper.writeValueAsString(expectedMapValue);
                         LinkedHashMap<String,Object> getObject = mapper.readValue(getstrObject,LinkedHashMap.class);

                         HashMap<String,Object> getexpectedKeyValue= NestedMapAssertionMethod(actualkey,getObject);
                         Object getexpectedValue = getexpectedKeyValue.get(actualkey);
                         if (getexpectedValue !=null){
                             AssertionMethods(actualkey,getObjectValue,actualkey,getexpectedValue);
                         }
                      }
                     else if (getType.equalsIgnoreCase("List")){

                        String getstrList = mapper.writeValueAsString(expectedMapValue);
                        ArrayList<Object> getexpectedList = mapper.readValue(getstrList,ArrayList.class);

                        Object getexpectedValue = NestedListAssertionMethod(actualkey,getexpectedList);
                        if (expectedMapValue !=null){
                             AssertionMethods(actualkey,getObjectValue,actualkey,getexpectedValue);
                        }
                     }

                     else if (getType.equalsIgnoreCase("String")){
                        AssertionMethods(actualkey,getObjectValue,actualkey,expectedMapValue);
                     }
                  }
             }
        }

        public static HashMap<String,Object> ListtoString(String key,List value) throws Exception{

             HashMap<String,Object> getMapValue =null;

             Object getValue =null;

             for (Object getElement: value){
                 getValue = getElement;
                 String getType = checkJsonType(getValue);

                 if (getType.equalsIgnoreCase("List")){
                       List getObject = (List<Object>)getValue;
                       getValue = ListtoString(key,getObject);
                       getType = checkJsonType(getValue);
                       if (getType.equalsIgnoreCase("String")){
                         getMapValue.put(key,getValue);
                         return getMapValue;
                       }
                  }
                 else if (getType.equalsIgnoreCase("Map")){
                       LinkedHashMap<String,Object> getObject = (LinkedHashMap<String,Object>)getValue;
                       getValue = MaptoString(key,getObject);
                       if (getType.equalsIgnoreCase("String")){
                         getMapValue.put(key,getValue);
                         return getMapValue;
                       }
                 }
                 else if (key.equals(getValue)){
                       getMapValue.put(key,getValue);
                       return getMapValue;
                 }
             }

             return getMapValue;
        }

        public static HashMap<String,Object> MaptoString(String key,LinkedHashMap<String,Object> value) throws Exception{

          try{
             LinkedHashMap<String,Object> getMapObject = (LinkedHashMap<String,Object>) value;

             getMapValue.clear();

             Object getValue =null;

             for (Map.Entry<String,Object> getEntryObject: getMapObject.entrySet()){

                 String getType = checkJsonType(getEntryObject.getValue());
                 System.out.println(getEntryObject.getKey() + ":" + key + ":" + getType);

                 if (getType.equalsIgnoreCase("List")){
                       List getObject = (List<Object>)getEntryObject.getValue();
                       ListtoString(key,getObject);
                 } 
                 else if (getType.equalsIgnoreCase("Map")){
                       LinkedHashMap<String,Object> getObject = (LinkedHashMap<String,Object>)getEntryObject.getValue();
                       MaptoString(key,getObject);
                 } 
                 else if ( (getEntryObject.getKey().equalsIgnoreCase(key)) && getType.equals("String") ){
                       System.out.println("entry object " + ":" + getEntryObject);
                       String newkey = getEntryObject.getKey();
                       getValue = getEntryObject.getValue();
                       getMapValue.put(newkey,getValue);
                       return getMapValue;
                 }
             }

            return getMapValue;
         }

         catch(Exception e){
            System.out.println(e.getMessage());
            return getMapValue;
         }



        }


        public static HashMap<String,Object> NestedMapAssertionMethod(String actualkey,LinkedHashMap<String,Object> m7) throws Exception{

            HashMap<String,Object> getexpectedValue = new HashMap<String,Object>();
            HashMap<String,Object> getexpectedKeyValue = new HashMap<String,Object>();

            for (Map.Entry<String,Object> key: m7.entrySet()){

             String getkey= key.getKey();
             Object getmap= key.getValue();

              String getType = checkJsonType(getmap);

                if (getType.equalsIgnoreCase("List")){
                     List getListObject = (List<Object>)getmap;
                     getexpectedValue = ListtoString(actualkey,getListObject);
                     if (getexpectedValue.entrySet().iterator().next().getKey().equals(actualkey)){
                        Object getValueContent = getexpectedValue.entrySet().iterator().next().getValue();
                        getexpectedKeyValue.put(actualkey,getValueContent);
                        return getexpectedKeyValue;
                     }
                }
                else if (getType.equalsIgnoreCase("Map")){
                      LinkedHashMap<String,Object> getMapObject = (LinkedHashMap<String,Object>)getmap;
                      getexpectedValue = MaptoString(actualkey,getMapObject);
                      if (getexpectedValue.entrySet().iterator().next().getKey().equals(actualkey)){
                        Object getValueContent = getexpectedValue.entrySet().iterator().next().getValue();
                        getexpectedKeyValue.put(actualkey,getValueContent);
                        return getexpectedKeyValue;
                     }
                }

                else{
                      if (m7.entrySet().iterator().next().getKey().equals(actualkey)){
                          Object expectedObjectvalue = m7.entrySet().iterator().next().getValue();
                          getexpectedKeyValue.put(actualkey,expectedObjectvalue);
                          return getexpectedKeyValue;
                      }
                  }
            }
                return getexpectedKeyValue;


        }



        public static Object NestedListAssertionMethod(String actualkey,ArrayList<Object> m12){

             Object getListValue=null;

             for (Object getValue: m12){
                 Object getType =  getValue.getClass().getName(); 
                 getListValue = getValue;
                 getTypeResult = wrapperClass(getType);

                 if (getTypeResult){
                    return getListValue ;
                 }
             }

            return getListValue ;
 
        }



        public static void validateDBOutput(String DB_Output){

            LinkedHashMap<String,Object> ExpectedDBOutput=null;

            try{
                 if (DB_Output!=null){

                      System.out.println("Entered into DB postcondition statement" + ":" + DB_Output);

                      Map<java.lang.String,java.lang.String> ActualDBOutput=null;

                      String[] PostDBQueryObjectkey = DB_Output.split(":");
                      if (PostDBQueryObjectkey[0].equalsIgnoreCase("HGETALL")){
                           ActualDBOutput = DbRedisExecutor.getHashValue(PostDBQueryObjectkey[0]);
                      }

                      ExpectedDBOutput=APIRequest.stringtoMap(PostDBQueryObjectkey[1],"=");
                      System.out.println(ActualDBOutput);
                      System.out.println(ExpectedDBOutput);
                      boolean DBCompare = ActualDBOutput.equals(ExpectedDBOutput);
                      softAssert.get().assertTrue(DBCompare);
                   }
             }
             catch(Exception e){
                 e.printStackTrace();
            }
        }


        public static Object getPreconditionQuery(String testCaseName,String DependenttestCaseName,String DB_Condition){

          try{
                System.out.println("TestCase name: " + DependenttestCaseName);

                if (!(DependenttestCaseName.equals("NA"))){

                    LinkedHashMap<String,List<Object>> getResult = DBRequestExecutor.DbMethodFetchQuery(DependenttestCaseName);
   
                    List<Object> getResponseDB = getResult.get(DependenttestCaseName);
   
                    getHeaders = (String) getResponseDB.get(0);

                    getBody = (String) getResponseDB.get(1);

                    getBodyMap  = APIRequest.stringtoMap(getBody,":");

                    String getExpectedResponseObject = mapper.writeValueAsString(DB_Condition); 
 
                    getOutput = APIRequest.MaptoString(getExpectedResponseObject,getBodyMap);

                    System.out.println("Output " + getOutput);

                 }

                return getOutput;
          }
          catch(Exception e){

            e.printStackTrace();

            return getOutput;

          }
        }


        public static String getDBQueryOutput(Response response,String DBQueryInput){

          String getRedisDBOutputValue = null;

          try{
             JsonPath getJsonValue = response.jsonPath();
             getRedisDBOutputValue = getJsonValue.getString(DBQueryInput);
          }
          catch(Exception e){
            e.printStackTrace();
          }
          return getRedisDBOutputValue;
        }

        public static void tearDown(ITestResult result){
             if (result.getStatus()==ITestResult.FAILURE){
                    ExtentTestManager.getTest().log(Status.FAIL,"TestCase is Failed");
             }
             else if (result.getStatus()==ITestResult.SKIP){
                    ExtentTestManager.getTest().log(Status.SKIP,"TestCase is skipped");
             }
             else{
                    ExtentTestManager.getTest().log(Status.PASS,"TestCase is Passed");
             }

             ExtentTestManager.endTest();
       }



	

}

