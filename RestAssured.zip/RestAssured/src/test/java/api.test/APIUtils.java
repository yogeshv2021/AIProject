package api.test;

import java.io.BufferedReader;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;

import org.json.JSONArray;
import org.json.JSONObject;
import com.opencsv.*;
import org.json.JSONTokener;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.asserts.SoftAssert;
import com.fasterxml.jackson.core.type.TypeReference;

import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;
import static io.restassured.RestAssured.*;
import io.restassured.http.Method;
import io.restassured.specification.RequestSpecification;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.*;

import io.restassured.response.*;
import io.restassured.matcher.RestAssuredMatchers.*;
import io.restassured.path.json.JsonPath;

import static org.hamcrest.Matchers.*;
import io.restassured.response.ExtractableResponse;
import io.restassured.response.ValidatableResponse;

import org.testng.asserts.SoftAssert;
import org.testng.ITestResult;
import org.testng.Reporter;
import java.util.Properties;
import api.utilities.DataProviders;
import io.restassured.response.*;
import io.restassured.matcher.RestAssuredMatchers.*;
import io.restassured.path.json.JsonPath;

import static org.hamcrest.Matchers.*;
import io.restassured.response.ExtractableResponse;
import io.restassured.response.ValidatableResponse;

import org.testng.asserts.SoftAssert;
import org.testng.ITestResult;
import org.testng.ITestContext;
import org.testng.Reporter;
import org.testng.annotations.*;
import org.testng.annotations.Test;
import java.util.Properties;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import api.endpoints.*;
import api.utilities.DataProviders;
import io.qameta.allure.*;

public class APIUtils extends Base{


       private static List<LinkedList<String>> setStoreDBValue= new LinkedList<LinkedList<String>>();
       private static ThreadLocal<List<String>> getStoreDBValue = ThreadLocal.withInitial(LinkedList::new);
       public static ThreadLocal<SoftAssert> softAssert= new ThreadLocal<>();
       private static ITestResult result =null;

	@Test(dataProvider="MergeRequestAndDBQueryData", dataProviderClass=DataProviders.class)
	public void getrequestcall(String TC_Name,String MicroService,String URL,String Request_Method,String Base_Path,String Request_Header,String Request_Body_Type,String Request_Body,String Response_Header,String Response_Body,String Status_Code,String Dynamic_Response_Header_Content,String Dynamic_Response_Body_Content,String DB_TC_Name,String DB_Dependent_Case,String DB_MicroService,String DB_Condition,String DB_Output_Query){            try{
               if (Request_Method.equals("GET")){
                    String requestBodyJson ="";
                    Object getPassValue = getPreconditionQuery(TC_Name,DB_Dependent_Case,DB_Condition);

                    Map<String,LinkedHashMap<String,Object>> getRequestContent= Base.requestPostContent(Request_Method,Request_Header,Request_Body_Type,Request_Body,getPassValue);
                    LinkedHashMap<String,Object> requestHeaderContent= getRequestContent.get("Header");
                    Response response = APIRequest.sendGetMethod(URL,Base_Path,requestHeaderContent);
                    Base.responsePostContent(Response_Header,Response_Body,Status_Code,response,Dynamic_Response_Header_Content,Dynamic_Response_Body_Content);
                }

             }
             catch(Exception e){
                 e.printStackTrace();
             }
	}

	
	@Test(dataProvider="MergeRequestAndDBQueryData", dataProviderClass=DataProviders.class)
	public void createrequestcall(String TC_Name,String MicroService,String URL,String Request_Method,String Base_Path,String Request_Header,String Request_Body_Type,String Request_Body,String Response_Header,String Response_Body,String Status_Code,String Dynamic_Response_Header_Content,String Dynamic_Response_Body_Content,String DB_TC_Name,String DB_Dependent_Case,String DB_MicroService,String DB_Condition,String DB_Output_Query){
            try{
                if (Request_Method.equals("POST")){
                    String requestBodyJson ="";
                    SoftAssert getAssert = new SoftAssert();
                    softAssert.set(getAssert);

                    int requestFlag =2;

                    getStoreDBValue.get().add(0,TC_Name);
                    getStoreDBValue.get().add(1,DB_Condition);
                    getStoreDBValue.get().add(2,DB_Output_Query);

                    System.out.println("Get DB Params:"  + getStoreDBValue);

                    Object getPassValue = getPreconditionQuery(TC_Name,DB_Dependent_Case,DB_Condition);

                    Map<String,LinkedHashMap<String,Object>> getRequestContent= Base.requestPostContent(Request_Method,Request_Header,Request_Body_Type,Request_Body,getPassValue);

                    requestFlag = (int) getRequestContent.get("Flag").get("dependentFlag");
                  

                    if (requestFlag ==1);
                    else{
                        
                         Object requestHeaderContent= getRequestContent.get("requestHeader");
                         Object requestBodyContent= getRequestContent.get("Body").get("requestBody");

                         System.out.println("Request Header in Post Method: " + " " + requestHeaderContent);
                         System.out.println("Request Body in Post Method: " + " " + requestBodyContent);

                         String requestStringBody = requestBodyContent.toString();

                         String requestStringHeader = mapper.writeValueAsString(requestHeaderContent);
                         Map<String,Object> jsonHeader = mapper.readValue(requestStringHeader,Map.class);
 
                         System.out.println(requestStringBody);
                         System.out.println(jsonHeader);

                         Response response = APIRequest.sendPostMethod(URL,Base_Path,jsonHeader,requestStringBody);
  
                         Base.responsePostContent(Response_Header,Response_Body,Status_Code,response,Dynamic_Response_Header_Content,Dynamic_Response_Body_Content);
                         System.out.println("DB Validation");

                         String Headers = response.headers().toString();
                         String Body = response.getBody().asString();
                         Integer StatusCode = response.getStatusCode();
                         DBRequestExecutor.DbMethodCreateQuery(TC_Name,Request_Method,URL,StatusCode,Headers,Body);

                         Allure.addAttachment("RequestContent",requestBodyJson);
                         Allure.addAttachment("RequestContent",response.getBody().asString());

                    }
                }
             }
             catch(Exception e){
                 e.printStackTrace();
             } 

	}


        @AfterMethod
	public void TearDown(ITestResult result){
            try{
                String testCaseName = (String) getStoreDBValue.get().get(0);
                softAssert.get().assertAll(); 
              }
             catch(Exception e){
                 e.printStackTrace();
             } 

	}
}
