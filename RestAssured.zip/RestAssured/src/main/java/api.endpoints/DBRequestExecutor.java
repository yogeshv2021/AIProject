package api.endpoints;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DBRequestExecutor{


    private static final String url = "jdbc:postgresql://postgres/cpaas_lyca_ireland";
    private static final String user = "root";
    private static final String password = "root123";
    public static String fname = null;

    public static Connection conn;
    public static PreparedStatement prst;
    public static ResultSet getqueryoutput;
    public static int getoutput;
    public static String Query ="Select * from response";

    public static ArrayList DbMethodCreateQuery(String TestCaseName,String Method,String Url,String Headers,String Body){
         String requestmethod =null;
         String requesturl =null;
         String requestheader =null;
         String requestbody =null;
         ArrayList setDBList = new ArrayList();
       try{
          Class.forName("org.postgresql.Driver");
          conn = DriverManager.getConnection(url,user,password);
          prst = conn.prepareStatement(Query);
          System.out.println("Connection to database is successfull");

          prst.setString(1,TestCaseName);
          getoutput = prst.executeUpdate();
   
          while (getqueryoutput.next()){
              String testcasename =  getqueryoutput.getString("TestCaseName");
              if (testcasename == null){
                 prst.setString(1,TestCaseName);
                 prst.setString(2,Method);
                 prst.setString(3,Url);
                 prst.setString(4,Headers);
                 prst.setString(5,Body); 
                 getoutput = prst.executeUpdate();                 
              }
              else{
                 requestmethod =  getqueryoutput.getString("request_method");
                 requesturl =  getqueryoutput.getString("request_url");
                 requestheader =  getqueryoutput.getString("request_header");
                 requestbody =  getqueryoutput.getString("request_body");
              }
         }

         setDBList.add(TestCaseName);
         setDBList.add(requestmethod);
         setDBList.add(requesturl);
         setDBList.add(requestheader);
         setDBList.add(requestbody);

      }
      catch(SQLException| ClassNotFoundException e){
              System.out.println("Exception occured" + e);
      }
      finally{
        try{
          if (conn !=null) {
            conn.close();
          }
          if (prst!=null) {
             prst.close();
          }
        }
        catch (SQLException e){
              System.out.println("Exception occured" + e);
        }
        return setDBList;
      }
    }

    public void DbMethodDeleteQuery(String Query){
       try{
          Class.forName("org.postgresql.Driver");
          conn = DriverManager.getConnection(url,user,password);
          prst = conn.prepareStatement(Query);
          System.out.println("Connection to database is successfull");
          getqueryoutput = prst.executeQuery();
   
          while (getqueryoutput.next()){
              System.out.println(getqueryoutput);
         }
      }
      catch(SQLException| ClassNotFoundException e){
              System.out.println("Exception occured" + e);
      }
      finally{
        try{
          if (conn !=null) {conn.close();};
          if (prst!=null) {prst.close();}; 
        }
        catch (SQLException e){
              System.out.println("Exception occured" + e);
        }
      }
    }

    public void DbMethodUpdateQuery(String Query){
       try{
          Class.forName("org.postgresql.Driver");
          conn = DriverManager.getConnection(url,user,password);
          prst = conn.prepareStatement(Query);
          System.out.println("Connection to database is successfull");
          getoutput = prst.executeUpdate();
   
          while (getqueryoutput.next()){
              System.out.println(getqueryoutput);
         }
      }
      catch(SQLException| ClassNotFoundException e){
              System.out.println("Exception occured" + e);
      }
      finally{
        try{
          if (conn !=null) {conn.close();};
          if (prst!=null) {prst.close();}; 
        }
        catch (SQLException e){
              System.out.println("Exception occured" + e);
        }
      }
    }

    public void DbMethodSelectQuery(String TestCaseName,String Method,String Url,String Headers,String Body){
       try{
          Class.forName("org.postgresql.Driver");
          conn = DriverManager.getConnection(url,user,password);
          prst = conn.prepareStatement(Query);
          System.out.println("Connection to database is successfull");
          getoutput = prst.executeUpdate();
   
          while (getqueryoutput.next()){
              System.out.println(getqueryoutput);
         }
      }
      catch(SQLException| ClassNotFoundException e){
              System.out.println("Exception occured" + e);
      }
      finally{
        try{
          if (conn !=null) {conn.close();};
          if (prst!=null) {prst.close();}; 
        }
        catch (SQLException e){
              System.out.println("Exception occured" + e);
        }
      }
    }

}
