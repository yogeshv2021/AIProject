package api.endpoints;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;

import org.json.JSONArray;
import org.json.JSONObject;

import com.opencsv.*;
import org.json.JSONTokener;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;



import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;
import static io.restassured.RestAssured.*;
import io.restassured.http.*;
import io.restassured.specification.RequestSpecification;
import io.restassured.builder.RequestSpecBuilder;

import io.restassured.response.*;
import io.restassured.matcher.RestAssuredMatchers.*;
import io.restassured.path.json.JsonPath;
import org.testng.ITestResult;


import static org.hamcrest.Matchers.*;
import io.restassured.response.ExtractableResponse;
import io.restassured.response.ValidatableResponse;

import org.testng.asserts.SoftAssert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.testng.annotations.Test;
import java.util.Properties;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.Status;
import api.utilities.DataProviders;
import api.utilities.ExtentTestManager;
import com.aventstack.extentreports.ExtentTest;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.*;
import org.junit.jupiter.api.BeforeAll;
import java.lang.reflect.Method;

public class Base extends ExtentTestManager{

        ExtentReports extent;
        static SoftAssert softAssert = new SoftAssert();

	@BeforeAll
	public void readproperties(){ 
	      String Filepath ="";
	      try{
	          Filepath = "Configuration.properties";
	          Properties properties= new Properties();
	          FileReader getFile = new FileReader(Filepath);
	          BufferedReader getObject = new BufferedReader(getFile);
	          properties.load(getObject);
	          getObject.close();
	          getFile.close();

	       }
	      catch(IOException e){
	          e.printStackTrace();
	      } 
	   }


          @BeforeMethod
          public static void setUp(Method method){
              ExtentTest test = ExtentTestManager.startUp(method.getName(),  "Description is " + method.getName()); 
              System.out.println(test);
          }
 
          public static Map<String,LinkedHashMap<String,Object>> requestPostContent(String Request_Method,String Request_Header,String Request_Body_Type,String Request_Body){

               Map<String,LinkedHashMap<String,Object>> requestHeaderBody = new HashMap<String,LinkedHashMap<String,Object>>();

               try{
                      LinkedHashMap<String,Object> headerContent = new LinkedHashMap<String,Object>();

                      String jsonbody = "";

                      String[] headerdata = Request_Header.split(";");
                      for (String header: headerdata){
                          String[] keyvalue = header.split(":");
                          headerContent.put(keyvalue[0],keyvalue[1]);
                      }

                     requestHeaderBody.put("requestHeader",headerContent);

           }
           catch(Exception e){
                 e.printStackTrace();
           } 

            return requestHeaderBody;

        }



           public static void responsePostContent(String Response_Header,String Response_Body,String Status_Code,Response response){

               try{
                      LinkedHashMap<String,Object> headerResponseContent = new LinkedHashMap<String,Object>();
                      LinkedHashMap<String,Object> bodyResponseContent = new LinkedHashMap<String,Object>();

                      String jsonbody = "";

                      String[] headerresponsedata = Response_Header.split(";");
                      for (String header: headerresponsedata ){
                          String[] keyvalue = header.split(":");
                          headerResponseContent.put(keyvalue[0],keyvalue[1]);
                      }

                      String[] bodyresponsedata = Response_Body.split(";");
                      for (String body: bodyresponsedata ){
                          String[] bodykeyvalue = body.split(":");
                          bodyResponseContent.put(bodykeyvalue[0],bodykeyvalue[1]);
                      }

                System.out.println(headerResponseContent);
                System.out.println(bodyResponseContent);

                Integer actualStatusCode = response.getStatusCode();
                String statusline = response.getStatusLine();
                Headers Actualresponseheader = response.headers();
                ResponseBody Actualresponsebody = response.getBody();
                String Actualjsonresponse = Actualresponsebody.asString();

                Integer expectedStatusCode = (int) Float.parseFloat(Status_Code);
                softAssert.assertEquals(actualStatusCode,expectedStatusCode);
 
                for (Map.Entry<String,Object> m1: headerResponseContent.entrySet()){
                     String expectedkey = m1.getKey();
                     String expectedvalue = m1.getValue().toString();
                     for (Header header: Actualresponseheader){
                       String ActualKey = header.getName();
                       if (expectedkey.equalsIgnoreCase(ActualKey)){
                           String ActualValue = response.header(ActualKey);
                           softAssert.assertEquals(expectedvalue,ActualValue,"No Match Found");
                           String ExpectedheaderResult= "Expected Header name: " + expectedkey + ", Expected Header value: " + expectedvalue;
                           String ActualheaderResult= "Actual Header name: " + ActualKey  + ", Actual Header value: " + ActualValue;
                           ExtentTestManager.test.log(Status.INFO,ExpectedheaderResult);
                           ExtentTestManager.test.log(Status.INFO,ActualheaderResult);
                       }
                    }
                }

                ObjectMapper mapper = new ObjectMapper();
                Map<String,Object> ActualBodymap = mapper.readValue(Actualjsonresponse,new TypeReference<Map<String,Object>>(){});


                for (Map.Entry<String,Object> m2: bodyResponseContent.entrySet()){
                     String expectedkey = m2.getKey();
                     String expectedvalue = m2.getValue().toString();
                     for (Map.Entry<String,Object> m3: ActualBodymap.entrySet()){
                       if (expectedkey.equalsIgnoreCase(m3.getKey())){
                           softAssert.assertEquals(expectedvalue,m3.getValue(),"No Match Found for response Body.");
                           String ExpectedBodyResult= "Expected Header name: " + expectedkey + ", Expected Header value: " + expectedvalue;
                           String ActualBodyResult= "Actual Header name: " + m3.getKey() + ", Actual Header value: " + m3.getValue();
                           ExtentTestManager.test.log(Status.INFO,ExpectedBodyResult);
                           ExtentTestManager.test.log(Status.INFO,ActualBodyResult);
                       }
                    }
                }

                softAssert.assertAll();

                System.out.println(ActualBodymap);

           }
           catch(Exception e){
               e.printStackTrace();
           }
        }


        @AfterMethod
        public static void tearDown(ITestResult result){
             if (result.getStatus()==ITestResult.FAILURE){
                    ExtentTestManager.getTest().log(Status.FAIL,"TestCase is Failed");
             }
             else if (result.getStatus()==ITestResult.SKIP){
                    ExtentTestManager.getTest().log(Status.SKIP,"TestCase is skipped");
             }
             else{
                    ExtentTestManager.getTest().log(Status.PASS,"TestCase is Passed");
             }

             ExtentTestManager.endTest();
       }



	

}
