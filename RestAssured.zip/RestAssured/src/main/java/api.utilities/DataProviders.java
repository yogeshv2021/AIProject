package api.utilities;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import api.endpoints.DBRequestExecutor;
import api.endpoints.DBResponseExecutor;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.ss.usermodel.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;



public class DataProviders{
	
        static String path="/opt/product/testteam/LoadScript/REPORT_GENERATION/src/test/resources/utils/TestData.xls";
        static String SheetName="Sheet1";
        static String TestCaseName;
        static String Method;
        static String Url;
        static String Headers;
        static String Body;
        static File FileObject;
        static FileInputStream f1;

	@DataProvider(name="getrequestData")
	public static Object[][] getNames() throws ArrayIndexOutOfBoundsException,IOException,FileNotFoundException{

            Object[][] data = null;

            try{
               FileObject = new File(path);
               DataFormatter formatter = new DataFormatter();
               f1 = new FileInputStream(FileObject);
               HSSFWorkbook b1 = new HSSFWorkbook(f1);
               HSSFSheet s1 = b1.getSheetAt(0);
	       int rowcount = s1.getLastRowNum();
               int cellcount = 0;
               for (int i=0;i<rowcount;i++){
                    HSSFRow row = s1.getRow(i);
                    cellcount = row.getLastCellNum();
               }

               data = new Object[rowcount][cellcount];


               for (int i=1;i<=rowcount;i++){
                    HSSFRow row = s1.getRow(i);
                    cellcount = row.getLastCellNum();
                    for (int j=0;j<cellcount;j++){
                        HSSFCell cell = row.getCell(j);
                        String getcelldata = getCellType(cell);
                        String celldata = getcelldata;
                        data[i-1][j]=celldata;
                    }
               }
               /*DBRequestExecutor.DbMethodCreateQuery(TestCaseName,Method,Url,Headers,Body);*/
             }
             catch(Exception e){
                  e.printStackTrace();
             }
             finally{
                System.out.println("Data provided to base class for execution");
                f1.close();
                return data;
            }
      }
	
	  static String getCellType(Cell cell) {
		  
		  String result="";
		  
		  CellType type = cell.getCellType();
		  
		  switch (type) {
		      case STRING:
		    	 result=cell.getStringCellValue();
		      break;
		      case NUMERIC:
		    	  result=String.valueOf(cell.getNumericCellValue());
			      break;
		      case BOOLEAN:
		    	  result=String.valueOf(cell.getBooleanCellValue());
			      break;
		      case ERROR:
		    	  result=String.valueOf(cell.getErrorCellValue());
			      break;
		      case BLANK:
		    	  result="";
			      break;
			  default:
			      result="";
		  }
		  return result;
	  }
}
