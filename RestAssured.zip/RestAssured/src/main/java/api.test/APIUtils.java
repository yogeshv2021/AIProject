package api.endpoints;

import java.io.BufferedReader;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;

import org.json.JSONArray;
import org.json.JSONObject;
import com.opencsv.*;
import org.json.JSONTokener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.testng.Assert;

import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;
import static io.restassured.RestAssured.*;
import io.restassured.http.Method;
import io.restassured.specification.RequestSpecification;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.*;

import io.restassured.response.*;
import io.restassured.matcher.RestAssuredMatchers.*;
import io.restassured.path.json.JsonPath;

import static org.hamcrest.Matchers.*;
import io.restassured.response.ExtractableResponse;
import io.restassured.response.ValidatableResponse;

import org.testng.asserts.SoftAssert;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.junit.jupiter.api.*;
import java.util.Properties;
import api.utilities.DataProviders;
import io.restassured.response.*;
import io.restassured.matcher.RestAssuredMatchers.*;
import io.restassured.path.json.JsonPath;

import static org.hamcrest.Matchers.*;
import io.restassured.response.ExtractableResponse;
import io.restassured.response.ValidatableResponse;

import org.testng.asserts.SoftAssert;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.junit.jupiter.api.*;
import org.testng.annotations.Test;
import java.util.Properties;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.fasterxml.jackson.databind.ObjectMapper;
import api.endpoints.*;
import api.utilities.DataProviders;

public class APIUtils extends Base{


	
       @Test(dataProvider="getrequestData", dataProviderClass=DataProviders.class)
	public void getrequestcall(String TC_Name,String MicroService,String URL,String Request_Method,String Base_Path,String Request_Header,String Request_Body_Type,String Request_Body,String Response_Header,String Response_Body,String Status_Code,String Result){
            try{
               if (MicroService.equals("GetOtpService")){
                    String requestBodyJson ="";
                    Map<String,LinkedHashMap<String,Object>> getRequestContent= Base.requestPostContent(Request_Method,Request_Header,Request_Body_Type,Request_Body);
                    LinkedHashMap<String,Object> requestHeaderContent= getRequestContent.get("requestHeader");
                    Response response = APIRequest.sendGetMethod(URL,Base_Path,requestHeaderContent);
                    Base.responsePostContent(Response_Header,Response_Body,Status_Code,response);
                }

             }
             catch(Exception e){
                 e.printStackTrace();
             }
	}


	
	@Test(dataProvider="getrequestData", dataProviderClass=DataProviders.class)
	public void createrequestcall(String TC_Name,String MicroService,String URL,String Request_Method,String Base_Path,String Request_Header,String Request_Body_Type,String Request_Body,String Response_Header,String Response_Body,String Status_Code,String Result){
            try{
                if (MicroService.equals("OtpService")){
                    String requestBodyJson ="";
                    Map<String,LinkedHashMap<String,Object>> getRequestContent= Base.requestPostContent(Request_Method,Request_Header,Request_Body_Type,Request_Body);
                    LinkedHashMap<String,Object> requestHeaderContent= getRequestContent.get("requestHeader");
                    LinkedHashMap<String,Object> requestBodyContent= getRequestContent.get("requestBody");
                    if (Request_Body_Type.equals("JSON")){
                          ObjectMapper mapper = new ObjectMapper();
                          requestBodyJson = mapper.writeValueAsString(requestBodyContent);
                    }
                    Response response = APIRequest.sendPostMethod(URL,Base_Path,requestHeaderContent,requestBodyJson);
                    Base.responsePostContent(Response_Header,Response_Body,Status_Code,response);
                }
             }
             catch(Exception e){
                 e.printStackTrace();
             } 

	}
}
