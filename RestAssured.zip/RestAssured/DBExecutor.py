import sqlite3
import os
from flask import Flask, request, session, g, redirect, url_for, abort, flash


app = Flask(__name__, instance_relative_config=True) # to create a application instance

class dbexecutor:

    def __init__(self):
        app.config.from_pyfile('Dbconfig.py')
        self.database=app.config['DATABASE']
        self.currentpath=app.root_path
        self.database_path=os.path.join(self.currentpath,self.database)
        print(self.database_path)


    def connect_db(self): 
        """Connects to the specific database."""
        connection = sqlite3.connect(self.database)
        connection.row_factory = sqlite3.Row
        return connection


    def get_db(self): 
        """get the connection from the specific database."""
        with app.app_context():
            if not hasattr(g,'sqlite_db'):
                g.sqlite_db = self.connect_db()
            return g.sqlite_db

    def init_db(self): 
        with app.app_context():
            db = self.get_db()
            with app.open_resource('schema.sql', mode='r') as f:
                db.cursor().executescript(f.read())
            db.commit()

    @app.cli.command('initdb')
    def initdb_command():
        """Initializes the database."""
        init_db()
        print('Initialized the database.')

    def db_execute(self):
        try:
            self.getdb = self.get_db()
            cursor = self.getdb.execute(''' CREATE TABLE IF NOT EXISTS AutoRequestResponse(id integer primary key autoincrement,TestcaseId varchar(200) not null,Testcasenum integer not null,Type varchar(1000) not null,Language varchar(100) not null,Request varchar(60000) not null,Response varchar(60000) null,Remarks varchar(2000) null,CreatedDate Datetime default current_timestamp) ''')
            cursor = self.getdb.execute(''' CREATE TABLE IF NOT EXISTS Result_table(id integer primary key autoincrement,TestcaseId varchar(200) not null,Testcasenum integer not null,Request varchar(60000) not null,Type varchar(1000) not null,Language varchar(100) not null,ExpectedResponse varchar(60000) null,ActualResponse varchar(60000) null,TestcaseStep_Status integer null,Testcase_Status varchar(1000) null,CreatedDate Datetime default current_timestamp) ''')
            cursor.close()
            self.getdb.close()

        except sqlite3.Error as e:
            print(e)


    def db_insert(self,tup):
        getdb = self.get_db()
        cur = getdb.cursor()
        cur.execute(''' INSERT or IGNORE into AutoRequestResponse(TestcaseId,Testcasenum,Type,Language,Request,Response,Remarks,CreatedDate) values(?,?,?,?,?,?,?,?) ''',tup)
        #cur.execute(''' DELETE FROM AutoRequestResponse ''')
        getdb.commit()
        cur.close()
        getdb.close()

    def db_update(self,tup):
        try:
            getdb = self.get_db()
            cur = getdb.cursor()
            print(tup)
            cur.execute(''' UPDATE AutoRequestResponse set Type=(?),Language=(?),Request=(?),Response=(?),Remarks=(?)  where TestcaseId=(?) and Testcasenum =(?) and Type=(?) ''',tup)
            getdb.commit()
            print("Record Updated successfully")
            getdb.close()

        except sqlite3.Error as e:
            print(e)


    def dbselect(self,tup):
        getdb = self.get_db()
        cur = getdb.cursor()
        testcaseparams = tup[0:4]

        if tup[-1]==0:
            cur.execute(''' SELECT * from AutoRequestResponse where TestcaseId =(?) and Testcasenum =(?) and Type =(?) and Request =(?) ''',testcaseparams)        
            getrow = cur.fetchone()
            cur.close()
            getdb.close()
            return getrow

        elif tup[-1]==1:
            cur.execute(''' SELECT * from AutoRequestResponse where TestcaseId =(?) and Testcasenum =(?) and Type =(?) and Request =(?) and Response is not NULL ''',testcaseparams)        
            getrow = cur.fetchone()
            cur.close()
            getdb.close()
            return getrow

    def dbselect1(self):
        getdb = self.get_db()
        cur = getdb.cursor()
        cur.execute(''' SELECT * from AutoRequestResponse ''')        
        getrow = cur.fetchall()
        cur.close()
        getdb.close()
        return getrow


    def db_autoresult(self,tup):
        getdb = self.get_db()
        cur = getdb.cursor()
        print(tup)
        cur.execute(''' INSERT into Result_table(TestcaseId,Testcasenum,Request,Type,Language,ExpectedResponse,ActualResponse,TestcaseStep_Status,Testcase_Status,CreatedDate) values(?,?,?,?,?,?,?,?,?,?) ''',tup)
        getdb.commit()
        cur.close()
        getdb.close()


    def getdbresult(self,firsttime,lasttime):
        tup=(firsttime,lasttime)
        getdb = self.get_db()
        cur = getdb.cursor()
        cur.execute(''' SELECT * from Result_table where CreatedDate between (?) and (?)''',tup)
        getrows=cur.fetchall()
        cur.close()
        getdb.close()
        return getrows
