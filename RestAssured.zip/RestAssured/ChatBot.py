import websocket
import threading
import time
import csv
import pandas as pd
import json
import os
import logging
import datetime
import sqlite3
#import requests
import numpy as np
from DBExecutor import (dbexecutor)
from intent import Dynamic_Response_Validation


config="/opt/product/testteam/LoadScript/RagAsTesting/config/configuration.json"
reportpath="/opt/product/testteam/LoadScript/RagAsTesting/report/"

logging.basicConfig(
    level=logging.DEBUG,  # Set the logging level
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',  # Log format
    handlers=[
        #logging.FileHandler("/opt/product/testteam/LoadScript/RagAsTesting/loadtestlog.log")  # Log to a file
        logging.StreamHandler()  # Log to console
    ]
)

logger = logging.getLogger(__name__)

class Chatbot(dbexecutor):

    def __init__(self):

        super().__init__()
        self.getjson = pd.read_json(config,orient="columns")
        self.getrow = self.getjson["Configuration"]
        self.lock = threading.Lock()
        self.firsttime = self.gettime(0)

        for getkeys,values in self.getrow.items():
            self.client = values["client"]
            self.gatewayurl = values["api-gateway-url"]
            self.gatewayhttpurl = values["external-gateway-http-url"]
            self.tokengenerateurl = values["tokengenerate-url"]
            self.externalgateway = values["external-gateway"]
            self.token = values["token"]
            self.queryfile = values["csvfile"]
            self.testfile = values["testcasefile"]
            self.statsfile = values["statsfile"]
            self.externalgatewaytoken =  self.externalgateway + "/" + self.token

       
    def write_to_csv(self,file_name, testcasename, thread_id, total_sent, total_received, avg_latency):

        with self.lock:

            file_exists = os.path.isfile(self.statsfile)

            with open(file_name, mode='a', newline='') as file:
                writer = csv.writer(file)
            
                if not file_exists:
                    writer.writerow(['Thread ID', 'TestCaseName', 'Total Messages Sent', 'Total Messages Received', 'Average Latency (seconds)'])
                
                writer.writerow([thread_id, testcasename, total_sent, total_received, avg_latency])

    def timefunction(self,args=0,timemax=5):

        if args==0:
            self.timemax=timemax
            self.current_epoch_time= time.time()
            self.current_time=datetime.datetime.fromtimestamp(self.current_epoch_time).strftime('%Y-%m-%d %H:%M:%S')

            self.max_wait_epoch_time = time.time() + timemax
            self.max_wait_time=datetime.datetime.fromtimestamp(self.max_wait_epoch_time).strftime('%Y-%m-%d %H:%M:%S')
            return self.max_wait_time

        elif args==1:

            self.delta_epoch_time = time.time()
            self.current_delta_time = datetime.datetime.fromtimestamp(self.delta_epoch_time).strftime('%Y-%m-%d %H:%M:%S')
            self.delta_time = datetime.datetime.strptime(self.max_wait_time,'%Y-%m-%d %H:%M:%S') - datetime.datetime.strptime(self.current_delta_time,'%Y-%m-%d %H:%M:%S')
            return int(self.delta_time.total_seconds())

    def gettime(self,timevalue):
        if timevalue==0:
            self.first_epoch_time = time.time()
            self.first_time = datetime.datetime.fromtimestamp(self.first_epoch_time).strftime('%Y-%m-%d %H:%M:%S')
            return self.first_time

        elif timevalue==1:
            self.last_epoch_time = time.time()
            self.last_time = datetime.datetime.fromtimestamp(self.last_epoch_time).strftime('%Y-%m-%d %H:%M:%S')
            return self.last_time

    
    def on_message(self, ws, message, thread_stats):

        logger.debug(f"Thread-{threading.get_ident()} response received on websocket: {message}") 

        getid=threading.get_ident()

        self.respid=str(getid) + "_" + str(self.thread_stats['current_line_index'])

#        self.check_timer(self.respid,self.thread_stats['current_line_index'],1)
#        time.sleep(0.05)
#        self.inputdb=[]
#        self.tclist=[]

        

        try:
            data = json.loads(message)

        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error: {e} - Message: {message}")
            return

        try:      
   
            latency = None

            message_type = data.get("type")

            if message_type != "complete" and message_type != "stream":
                self.thread_stats['accumulated_responses']=[]
 
            if message_type:
                response = data['content']

            if message_type == "mobileNoPattern":
                self.getclientId = data["clientId"]

            if message_type == "language":
                self.getclientId = data["clientId"]
       
            if ( message_type == "stream" or message_type == "complete") and message_type not in ["validated_otp","error","message"]:
                self.thread_stats['accumulated_responses'].append(response)
                self.thread_stats['chatbot_responses'].append(response)
                ExpectedResponse = "".join(self.thread_stats['chatbot_responses'][1:])
                if message_type == "complete":
                    testcaseName= self.thread_stats['testcasename']
                    responseObject = Dynamic_Response_Validation(testcaseName,ExpectedResponse)
                    responseObject.loadFile()

            elif message_type not in ["stream"]:
                with self.lock:
                    if self.thread_stats['current_line_index'] in self.thread_stats['sent_timestamps']:
                        sent_time = self.thread_stats['sent_timestamps'][self.thread_stats['current_line_index']]
                        latency = time.time() - sent_time

                        self.thread_stats['total_messages_received'] += 1
                        if latency is not None:
                             self.thread_stats['latencies'].append(latency)

                    self.thread_stats['accumulated_responses'].append(response)

     
                    if self.thread_stats['current_line_index'] <= len(self.thread_stats['csv_data'].index):

                        self.responsecount += 1

                        if type(self.thread_stats['accumulated_responses']) == list and message_type == "language":
                            dbresponse = self.thread_stats['accumulated_responses']
                            print("map")

                        else:
                            dbresponse = "".join(self.thread_stats['accumulated_responses'])
                            print("dbresponse %s" %dbresponse)

                        testcasename = self.thread_stats['testcasename']
                        testcaseindex = self.thread_stats['current_line_index']

                        db_type_input = self.thread_stats['csv_data']["Type"][self.thread_stats['current_line_index']]
                        db_language_input = self.thread_stats['csv_data']["language"][self.thread_stats['current_line_index']]
                        db_message_input = self.thread_stats['csv_data']["Message"][self.thread_stats['current_line_index']]

                        db_query_request= {"type": db_type_input, "message": db_message_input, "language": db_language_input}
      
                        self.executedb(testcasename,self.responsecount,db_query_request,dbresponse)

                        if int(self.responsecount) == int(self.thread_stats['csv_data']["responsecount"][self.thread_stats['counter']]) and self.thread_stats['current_line_index']<len(self.thread_stats['csv_data'].index):

                            thread_stats['counter']= thread_stats['counter'] + 1

                            next_type_input = self.thread_stats['csv_data']["Type"][self.thread_stats['counter']]

                            next_user_input = self.thread_stats['csv_data']["Message"][self.thread_stats['counter']]

                            next_user_language= self.thread_stats['csv_data']["language"][self.thread_stats['counter']]
	
                            next_agentcall= bool(self.thread_stats['csv_data']["agentcallflag"][self.thread_stats['counter']])

                            next_agenttype= self.thread_stats['csv_data']["agentType"][self.thread_stats['counter']]

                            next_menu= self.thread_stats['csv_data']["menu"][self.thread_stats['counter']]

                            next_question_id= self.thread_stats['csv_data']["question_id"][self.thread_stats['counter']]


                            query_request= {"type": next_type_input, "message": next_user_input, "language": next_user_language,"clientId":self.getclientId,"isAgentCall":next_agentcall,"agentType":next_agenttype,"menu":next_menu,"question_id":next_question_id}

                            json_request= json.dumps(query_request)

                            time.sleep(2)

                            print("Sleeping before next send request")
 
                            ws.send(json_request)

                            self.thread_stats['accumulated_responses']=[]

                            self.responsecount=0

                            logger.debug(f"Thread-{threading.get_ident()}  message Send: {json_request}")

                            getid=threading.get_ident()

                            self.reqid=str(getid) + "_" + str(self.thread_stats['current_line_index'])

#                           self.check_timer(self.reqid,self.thread_stats['current_line_index'],0)
  
                            self.thread_stats['total_messages_sent'] += 1

                            self.thread_stats['sent_timestamps'][self.thread_stats['current_line_index'] + 1] = time.time()

                            self.thread_stats['current_line_index'] += 1

                            self.thread_stats['accumulated_responses']=[]

                        elif int(self.responsecount) == int(self.thread_stats['csv_data']["responsecount"][self.thread_stats['counter']]) and self.thread_stats['current_line_index']==len(self.thread_stats['csv_data'].index):

                            logger.debug(f"Thread-{threading.get_ident()} finished processing all questions.")

                            ws.close()

                    else:
                        logging.debug(self.thread_stats['accumulated_responses'])
                        logger.debug(f"Thread-{threading.get_ident()} finished processing all questions.")
                        ws.close()

        except Exception as e:
            print(f"Exception occured during receive message processing {e}")
            ws.close()

        except KeyboardInterrupt as error:
            print("Interrupted")
            sys.exit(0)

    def check_timer(self,reqrespid,index,value,count=0):

        print(len(reqrespid),value)

        self.getrespid=""

        if count==0:
             self.max_wait_time=self.timefunction(0)

        if value==0:
            self.getreqid=reqrespid

        if value==1:
            self.getrespid=reqrespid
            return

        deltatime=self.timefunction(1)

        while len(self.getrespid)==0:
            print(self.getreqid,len(self.getrespid))
            if self.getreqid!=self.getrespid:
                time.sleep(1)
                count +=1
                if count<=deltatime:
                    self.on_message(self.ws, "{}", self.thread_stats)
                    return self.check_timer(self.getreqid,index,0,count)
        else:
            if self.getreqid==self.getrespid:
                print("sleep is completed.")


        print(count,deltatime,self.getreqid,index)
#       thread_stats['counter']= thread_stats['counter']+1


    def on_error(self,ws, error):
        logging.error(f"Error: {error}")
        
    def on_close(self,ws, close_status_code, close_msg, thread_stats):
        try:
            average_latency = sum(self.thread_stats['latencies']) / len(self.thread_stats['latencies']) if self.thread_stats['latencies'] else 0.0
            self.write_to_csv(self.statsfile, self.thread_stats['testcasename'], threading.get_ident(), self.thread_stats['total_messages_sent'], 
                      self.thread_stats['total_messages_received'], average_latency)
            logging.debug(f"Thread-{threading.get_ident()} Stats Completed") 

        except Exception as e:
            print("Exception occured during close {e}")

    def executedb(self,testcasename,indexname,data,*dbresponse):

        try:
            self.inputdb=[]
            self.tclist=[]

            self.current_epoch_time = time.time()
            self.current_time = datetime.datetime.fromtimestamp(self.current_epoch_time).strftime('%Y-%m-%d %H:%M:%S')

            self.db_execute()
#            testcaseindex = self.thread_stats['current_line_index']
       
            testcaseindex = int(indexname)
            self.tclist.extend([testcasename,testcaseindex,data["type"],data["message"],0])
            getrow = self.dbselect(tuple(self.tclist))

            if getrow is None:
                self.inputdb=[]
                self.inputdb.extend([testcasename,testcaseindex,data["type"],data["language"],data["message"],None,None,self.current_time])
                self.db_insert(tuple(self.inputdb))

            self.tclist=[]
            self.tclist.extend([testcasename,testcaseindex,data["type"],data["message"],1])
            getrow = self.dbselect(tuple(self.tclist))
            print("row %s" %getrow)

            if getrow is None:
                self.inputdb=[]
                if dbresponse:
                    self.inputdb.extend([data["type"],data["language"],data["message"],dbresponse[0],"Response Updated",testcasename,testcaseindex,data["type"]])
                else:
                    self.inputdb.extend([data["type"],data["language"],data["message"],None,"Response Updated",testcasename,testcaseindex,data["type"]])

                self.db_update(tuple(self.inputdb))

            elif getrow is not None and dbresponse:

                getvalue=[row for row in getrow]

                self.inputdb=[]

                if list(getvalue)[6] == dbresponse[0]:
                    TestcaseStep_Status=True
                else:
                    TestcaseStep_Status=False

                if TestcaseStep_Status==True:
                    Testcase_Status="Pass"

                else:
                    Testcase_Status="Fail"


                self.inputdb.extend([testcasename,testcaseindex,data["message"],data["type"],data["language"],list(getvalue)[6],dbresponse[0],TestcaseStep_Status,Testcase_Status,self.current_time])

                self.db_autoresult(tuple(self.inputdb))

#            getrow = self.dbselect1()
#            for i in getrow:
#                print(list(i))

        except Exception as error:
            print("Error occured while processing DB request %s" %error)


    def on_open(self,ws, thread_stats):

        logging.debug(f"Connection opened for thread {threading.get_ident()}")

        self.reqid=""
        self.respid=""


        if self.thread_stats['current_line_index'] < len(self.thread_stats['csv_data'].index):

            self._running=True
            user_type= self.thread_stats['csv_data']["Type"][self.thread_stats['current_line_index']]
            user_message= self.thread_stats['csv_data']["Message"][self.thread_stats['current_line_index']]
            user_language= self.thread_stats['csv_data']["language"][self.thread_stats['current_line_index']]
            user_agentcall_check= bool(self.thread_stats['csv_data']["agentcallflag"][self.thread_stats['current_line_index']])
            user_agenttype= self.thread_stats['csv_data']["agentType"][self.thread_stats['counter']]
            user_menu= self.thread_stats['csv_data']["menu"][self.thread_stats['counter']]
            user_question_id= self.thread_stats['csv_data']["question_id"][self.thread_stats['counter']]

            testcasename= self.thread_stats['testcasename']

            for type in self.readfile['Type']:
                if type == "greet":
                    query_request= {"type": user_type, "message": user_message, "language": user_language,"clientId":"","isAgentCall":user_agentcall_check,"agentType":user_agenttype,"menu":user_menu,"question_id":user_question_id}
                else:
                    query_request= {"type": user_type, "message": user_message, "language": user_language,"clientId":"","isAgentCall":user_agentcall_check,"agentType":user_agenttype,"menu":user_menu,"question_id":user_question_id}

            self.executedb(testcasename,self.thread_stats['current_line_index'],query_request)

            json_request = json.dumps(query_request)

            logging.debug(f"Thread-{threading.get_ident()}  message1: {json_request}") 

            ws.send(json_request)

            getid=threading.get_ident()

            self.responsecount=0

            self.reqid=str(getid) + "_" + str(self.thread_stats['current_line_index'])

#            self.check_timer(self.reqid,self.thread_stats['current_line_index'],0)
         
            with self.lock:
                self.thread_stats['total_messages_sent'] += 1

                self.thread_stats['sent_timestamps'][self.thread_stats['current_line_index']] = time.time()


               
    def connection(self):

#        print(self.readfile)

        jsoncontent = {'clientId':'cep-backend','clientSecret':'f9DccgecB6MH5bKWjtZoN2A1rEG4BANh','claimType':'client_credentials'}

        for idx,type in enumerate(self.readfile['Type']):

            tokenurl = self.readfile['Message'][idx]

            protocol = self.readfile['protocol'][idx]

            if type =="http" and protocol=="post":

                httpurl = self.gatewayhttpurl  + self.tokengenerateurl
   
                print(httpurl,jsoncontent)

                gettoken = requests.post(httpurl ,data=jsoncontent,headers={"Content-Type":"application/x-www-form-urlencoded"}) 
 
                getstatuscode = gettoken.status_code

                getresponse = gettoken.json()

                self.accesstoken = getresponse['accessToken']

                return type,self.accesstoken

            elif type =="http" and protocol=="get":

                requests.get(tokenurl) 


    def generate_report(self):

        print("Generating the report")

        try:

            self.lasttime = self.gettime(1)
            getrows = self.getdbresult(self.firsttime,self.lasttime)
            self.current_epoch_time= time.time()

            self.current_time=datetime.datetime.fromtimestamp(self.current_epoch_time).strftime('%Y-%m-%d %H:%M:%S')

            filename = "ChatBot_Report_" + self.current_time + ".csv"
            reportfilename = reportpath + filename
#            print(getrows,reportfilename)

            with open(reportfilename,"w+") as csvfile:
               writer = csv.writer(csvfile)
               writer.writerows(getrows)

        except Exception as e:
            print("Exception occured during Report writing %s" %e)

    def run_socket(self,testcase):

        self.testcase = testcase

        self.file = self.queryfile + "/" + self.testcase 

        self.readfile=pd.read_csv(self.file,index_col=False)
 
        self.wsfile=self.readfile[self.readfile['protocol'].isin(['ws'])]

        self.getdata=self.wsfile.iloc[:,1:]

        self.index=pd.Index(list(range(1,self.wsfile['Type'].size+1)),name='S.No',inplace=True)

        self.getdata.index=self.index

        self.getdata.replace(np.NaN,"",inplace=True)

        self.thread_stats = {
            'csv_data': self.getdata,
            'testcasename' : self.testcase,
            'current_line_index': 1,
            'accumulated_responses': [],
            'chatbot_responses': [],
            'total_messages_sent': 0,
            'total_messages_received': 0,
            'latencies': [],
            'sent_timestamps': {},
            'counter' : 1
        }

        type,accesstoken = self.connection()

        print("Type and Access token %s,%s" %(type,accesstoken))

        if type=="http":

            self.gatewaywithtoken = self.externalgatewaytoken + self.accesstoken

            self.ws = websocket.WebSocketApp(self.gatewaywithtoken,
                                    on_open = lambda ws: self.on_open(self.ws, self.thread_stats),
                                    on_message= lambda ws, msg: self.on_message(self.ws, msg, self.thread_stats),
                                    on_error= lambda ws,error: self.on_error(self.ws,error),
                                    on_close= lambda ws, close_status_code, close_msg: self.on_close(self.ws, close_status_code, close_msg, self.thread_stats))


        else:
            self.ws = websocket.WebSocketApp(on_open = lambda ws: self.on_open(self.ws, self.thread_stats),
                                    on_message= lambda ws, msg: self.on_message(self.ws, msg, self.thread_stats),
                                    on_error= lambda ws,error: self.on_error(self.ws,error),
                                    on_close= lambda ws, close_status_code, close_msg: self.on_close(self.ws, close_status_code, close_msg, self.thread_stats))
        self.ws.run_forever()


        
if __name__ == "__main__":

    getrag = Chatbot()
    print("Chatbot Object %s" %getrag)

    threads = []
    testcasefile=pd.read_csv(getrag.testfile)
    lock=threading.Lock()

    for testcase in testcasefile["TestCases"]:
        t = threading.Thread(target=getrag.run_socket,args=(testcase,))
        threads.append(t)
        t.start()
        t.join()

    getrag.generate_report()

    logging.info("All threads have completed.")

